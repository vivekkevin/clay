"""
ADDRESS ENRICHMENT PIPELINE - ENHANCED VERSION (GUI + MULTITHREADED)
====================================================================
This file keeps the ORIGINAL extraction logic 100% identical:
  - client / MODEL setup
  - build_queries / score_snippet / perform_web_search
  - SYSTEM_PROMPT / build_prompt / call_model
  - get_address / parse_response
  - the exact same output columns and values

Only two things were ADDED on top, as requested:
  1. A Tkinter GUI (pick input/output, set threads/checkpoint/max rows, start/stop, live log).
  2. Multithreaded row processing (ThreadPoolExecutor) inside process_pipeline.

Input and output remain the same as the original script. Because every row is
processed by the unchanged get_address() with temperature=0.0, the per-row result
is identical to the sequential version; only the order rows finish changes.

TECHNIQUES USED TO REDUCE NOT_FOUND & IMPROVE ACCURACY:

1. MULTI-QUERY STRATEGY: Run 3 different search queries (general, site-specific, LinkedIn/wiki)
   instead of 1. More shots = more chances to find real data.

2. CASCADING FALLBACK SEARCH: If Query 1 fails, auto-run Query 2, then Query 3.
   Only escalate when previous search yields weak results.

3. SMART QUERY VARIANTS: Build queries from different angles:
   - Full name + state + country
   - Shorter/cleaned name variants (removes "Pvt Ltd", "LLC" noise)
   - Registered office / corporate HQ searches

4. SOURCE EXPANSION: Search across multiple high-trust data sources:
   opencorporates, dnb.com, zaubacorp.com, tofler.in, bloomberg,
   crunchbase, indiamart, justdial, yellowpages

5. RESULT SCORING: Score each search result snippet (0-3) based on
   keywords like "address", "located at", "registered office" etc.
   Best-scored snippet goes first in the prompt context.

6. CITY-LEVEL VALIDATION: Post-extraction, validate that extracted address
   contains at minimum a city/district. If only country/state found, mark
   as PARTIAL instead of dropping it as NOT_FOUND.

7. ANTI-HALLUCINATION GROUNDING: Strict system prompt forces model to:
   - Only use text explicitly present in web search results
   - Never invent street numbers or names
   - If city-level is all that's found, output city + state + country (still useful)
   - Explicitly forbid "approximately" or "near" style guesses

8. STRUCTURED CONFIDENCE SCORING: Model outputs a confidence field (HIGH/MED/LOW)
   allowing downstream filtering.

9. RETRY WITH QUERY EXPANSION: If model returns NOT_FOUND on first attempt,
   auto-retry with a broader search query (just company name, no site filters).

10. CHECKPOINT RECOVERY: Saves every N rows so partial runs are not lost.
    On re-run, skips already-processed rows.
"""

import os
import re
import sys
import time
import queue
import threading
import urllib.parse
import pandas as pd
from tqdm import tqdm
from openai import OpenAI
from ddgs import DDGS
import random
from concurrent.futures import ThreadPoolExecutor, as_completed

# ─────────────────────────────────────────────
# CLIENT SETUP
# ─────────────────────────────────────────────
client = OpenAI(
    api_key="sk-Os-VNaj_3IreOr9xTfQKew",
    base_url="https://chatapi.straive.com",
    timeout=30.0
)

MODEL = "openai/gemini/gemini-2.5-flash"

# ─────────────────────────────────────────────
# TECHNIQUE 1 & 2: MULTI-QUERY WEB SEARCH WITH CASCADING FALLBACK
# ─────────────────────────────────────────────

TRUSTED_SITES = (
    "(site:opencorporates.com OR site:dnb.com OR site:zaubacorp.com OR "
    "site:tofler.in OR site:indiafilings.com OR site:instafinancials.com)"
)

def build_queries(issuer: str, company: str, city: str, state: str, country: str) -> list[str]:
    """
    TECHNIQUE 3: SMART QUERY VARIANTS
    Builds 4 different queries from narrow → broad.
    """
    # FIXED: Safely combine city, state, and country into one location string
    location_parts = [loc for loc in [city, state, country] if loc]
    location = " ".join(location_parts).strip()
    
    search_target = f"{issuer} {company}".strip()

    # Remove legal suffixes that add noise to searches
    clean_name = re.sub(
        r"\b(pvt|ltd|llc|inc|corp|limited|private|public|gmbh|llp|lp|plc|sa|ag|bv|nv|pty)\b",
        "", search_target, flags=re.IGNORECASE
    ).strip()

    queries = [
        # Q1: Narrow — trusted corporate registries with full name
        f"{search_target} {location} ({TRUSTED_SITES}) registered office address",

        # Q2: Medium — cleaned name, broader sites, "headquarters"
        f'"{clean_name}" {location} headquarters address',

        # Q3: Broad — just name + location, no site filters (catches news, press releases)
        f"{search_target} {location} address location",

        # Q4: Last resort — solar/infrastructure projects often have project-level pages
        f"{search_target} {location} project site location GPS",
    ]
    return queries


def score_snippet(snippet: str) -> int:
    """
    TECHNIQUE 5: RESULT SCORING
    Score a search result snippet by how likely it contains a real address.
    Higher = better. Used to rank snippets before sending to the model.
    """
    score = 0
    address_keywords = [
        "address", "located at", "registered office", "headquartered",
        "office at", "pincode", "zip code", "postal code", "street",
        "road", "nagar", "sector", "district", "block", "floor",
        "building", "tower", "plot", "survey no", "village",
    ]
    for kw in address_keywords:
        if kw.lower() in snippet.lower():
            score += 1
    return score


def perform_web_search(queries: list[str], max_results_per_query: int = 5) -> tuple[str, str]:
    all_snippets = []
    fallback_url = f"https://www.google.com/search?q={urllib.parse.quote(queries[0])}"

    # Use a context manager to reuse the underlying request session
    with DDGS() as ddgs:
        for q_idx, query in enumerate(queries):
            try:
                # Add a small polite random delay before hitting the search
                time.sleep(random.uniform(1.5, 3.0)) 
                
                results = ddgs.text(query, max_results=max_results_per_query)
                if not results:
                    continue

                for res in results:
                    title = res.get("title", "").strip()
                    body = res.get("body", "").strip()
                    snippet = f"{title} - {body}"
                    href = res.get("href", "")
                    if snippet:
                        score = score_snippet(snippet)
                        all_snippets.append((score, snippet, href, q_idx + 1))

                top_scores = [s[0] for s in all_snippets]
                if top_scores and max(top_scores) >= 3:
                    break  

            except Exception as e:
                tqdm.write(f"   [WARN] Search query {q_idx+1} failed: {e}")
                # If blocked, sleep longer
                time.sleep(5)
                continue

    if not all_snippets:
        return "No web results found.", fallback_url

    # Sort by score descending (best snippets first)
    all_snippets.sort(key=lambda x: x[0], reverse=True)

    context_lines = []
    for rank, (score, snippet, href, q_num) in enumerate(all_snippets[:6], 1):
        context_lines.append(
            f"Result {rank} [Query#{q_num}, Score={score}]: {snippet}\n  Source: {href}"
        )

    best_href = all_snippets[0][2] if all_snippets[0][2] else fallback_url
    return "\n\n".join(context_lines), best_href


# ─────────────────────────────────────────────
# TECHNIQUE 6 & 7: CITY-LEVEL VALIDATION + ANTI-HALLUCINATION PROMPT
# ─────────────────────────────────────────────

SYSTEM_PROMPT = """You are a corporate registry and physical asset verification engine.

YOUR ONLY JOB: Extract the real-world address, latitude, and longitude of the company or asset from the web search results provided.

STRICT GROUNDING RULES (read carefully):
- You may ONLY use text that is explicitly present in the LIVE WEB SEARCH RESULTS.
- If the search results contain a full address, extract it exactly.
- CRITICAL FIX FOR CHOPPED TEXT: Search snippets often cut off mid-sentence (e.g., "123 Main St, Buildi..."). If the street level address is cut off in the snippet, you MUST stitch it together by appending the expected Target City, State, and Country to the end of it so it forms a complete, usable address.
- If the search results contain only CITY + STATE + COUNTRY (no street), output just that. City-level is acceptable.
- NEVER invent street names or plot numbers not present in the results.
- If TRULY nothing geographic is found, output NOT_FOUND.

CONFIDENCE LEVELS:
- HIGH: Full address with street/building found in results
- MED: City + State + Country found in results (no street)
- LOW: Only country or state found
- NONE: Nothing found

OUTPUT FORMAT:
You MUST return a valid JSON object with EXACTLY the following keys. Do not add markdown formatting outside the JSON:
{
  "match_type": "EXACT, PARTIAL, or NOT_FOUND",
  "address": "Full physical address, or NOT_FOUND",
  "confidence": "HIGH, MED, LOW, or NONE",
  "latitude": "Extract latitude in Decimal format ONLY (e.g., 4.3930). Strip all letters and degree symbols. Leave blank if not found.",
  "longitude": "Extract longitude in Decimal format ONLY (e.g., 113.9900). Strip all letters and degree symbols. Leave blank if not found.",
  "justification": "Brief explanation of how this was verified"
}
"""

def build_prompt(issuer: str, company: str, city: str, state: str, country: str, web_context: str, fallback_url: str) -> str:
    # Added city to the location context so the AI knows exactly where it should be looking
    location = f"{city} {state} {country}".strip()
    
    return (
        f"Target Parent Issuer: '{issuer}'\n"
        f"Target Asset/Location Name: '{company}' (expected in: {location})\n\n"
        f"--- LIVE WEB SEARCH RESULTS ---\n{web_context}\n--- END RESULTS ---\n\n"
        "Now extract the best available physical address following the rules above.\n"
        f"For SOURCE_URL, use: {fallback_url}"
    )


# ─────────────────────────────────────────────
# TECHNIQUE 8 & 9: CONFIDENCE SCORING + RETRY ON NOT_FOUND
# ─────────────────────────────────────────────

import json

def call_model(prompt: str, max_retries: int = 3) -> dict:
    backoff = 2
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model="gemini/gemini-2.5-flash",
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT}, 
                    {"role": "user", "content": prompt},
                ],
                temperature=0.0,
                response_format={"type": "json_object"} # FORCES PERFECT JSON
            )
            return json.loads(response.choices[0].message.content.strip())
        except Exception as e:
            err = str(e)
            if "429" in err:
                wait = backoff ** attempt
                tqdm.write(f"   [RATE LIMIT] Waiting {wait}s...")
                time.sleep(wait)
            elif "timeout" in err.lower():
                return {"match_type": "ERROR", "address": "Server Timeout", "confidence": "NONE", "latitude": "", "longitude": "", "justification": "Proxy timed out."}
            else:
                return {"match_type": "ERROR", "address": "API Exception", "confidence": "NONE", "latitude": "", "longitude": "", "justification": f"Error: {err}"}
    return {"match_type": "ERROR", "address": "Max Retries Exceeded", "confidence": "NONE", "latitude": "", "longitude": "", "justification": "Failed to reach server."}


def get_address(issuer: str, company: str, city: str, state: str, country: str) -> dict:
    if (pd.isna(company) or str(company).strip() == "") and \
       (pd.isna(issuer) or str(issuer).strip() == ""):
        return {"match_type": "SKIP", "address": "Missing Data", "confidence": "NONE", "latitude": "", "longitude": "", "justification": "No input provided.", "source_url": ""}

    issuer = str(issuer).strip() if pd.notna(issuer) else ""
    company = str(company).strip() if pd.notna(company) else ""
    city = str(city).strip() if pd.notna(city) else ""         
    state = str(state).strip() if pd.notna(state) else ""
    country = str(country).strip() if pd.notna(country) else ""

    queries = build_queries(issuer, company, city, state, country)
    web_context, fallback_url = perform_web_search(queries)

    prompt = build_prompt(issuer, company, city, state, country, web_context, fallback_url)
    result = call_model(prompt)
    result["source_url"] = fallback_url

    # TECHNIQUE 9: AUTO-RETRY WITH BROADER QUERY if NOT_FOUND
    if result.get("match_type") == "NOT_FOUND":
        tqdm.write("   [RETRY] NOT_FOUND — retrying with broader search...")
        
        location_string = f"{city} {state} {country}".strip()
        broader_query = f"{issuer} {company} {location_string} address location contact"
        broad_context, broad_url = perform_web_search([broader_query]) 
        
        retry_prompt = build_prompt(issuer, company, city, state, country, broad_context, broad_url)
        retry_result = call_model(retry_prompt)
        retry_result["source_url"] = broad_url

        if retry_result.get("match_type") != "NOT_FOUND":
            retry_result["justification"] = "[RETRY] " + retry_result.get("justification", "")
            return retry_result

    return result

# ─────────────────────────────────────────────
# RESPONSE PARSER WITH TECHNIQUE 6: CITY-LEVEL VALIDATION
# ─────────────────────────────────────────────

def parse_response(raw: str, fallback_url: str) -> dict:
    """
    Robust parser that safely handles missing or extra pipe characters.
    """
    # Clean up newlines that might break parsing
    raw = raw.replace('\n', ' ').strip()
    parts = [p.strip() for p in raw.split("|")]
    
    # 1. Safely extract MATCH_TYPE (it should always be the first item)
    match_type = parts[0].upper() if len(parts) > 0 else "UNKNOWN"
    
    # Ensure it caught a valid match type (strips out noise)
    if "EXACT" in match_type: match_type = "EXACT"
    elif "PARTIAL" in match_type: match_type = "PARTIAL"
    elif "NOT_FOUND" in match_type: match_type = "NOT_FOUND"
    else: match_type = "UNKNOWN"

    # 2. Extract Address safely
    # If the AI forgot all pipes, we just dump the raw text minus the match type
    if len(parts) == 1:
        address = raw.replace("EXACT", "").replace("PARTIAL", "").replace("NOT_FOUND", "").replace("|", "").strip()
        confidence, justification, source_url = "LOW", "Failed to parse properly.", fallback_url
    else:
        address = parts[1]
        
        # If the AI hallucinated extra pipes INSIDE the address, we dynamically stitch them back together
        if len(parts) > 5:
            # Assume everything between Match Type (0) and Confidence (len-3) is the address
            address = ", ".join(parts[1:-3])
            confidence = parts[-3].upper()
            justification = parts[-2]
            source_url = parts[-1]
        else:
            confidence = parts[2].upper() if len(parts) > 2 else "NONE"
            justification = parts[3] if len(parts) > 3 else "Parsed short response."
            source_url = parts[4] if len(parts) > 4 else fallback_url

    source_url = source_url if source_url.startswith("http") else fallback_url

    # TECHNIQUE 6 FIX: Catch all common "empty" AI phrases
    invalid_address_terms = ["NOT_FOUND", "N/A", "NONE", "UNKNOWN", "-", ""]
    if match_type == "NOT_FOUND" and address.upper() not in invalid_address_terms:
        match_type = "PARTIAL"
        confidence = "LOW"

    return {
        "match_type": match_type,
        "address": address,
        "confidence": confidence if confidence in ["HIGH", "MED", "LOW", "NONE"] else "NONE",
        "justification": justification,
        "source_url": source_url,
    }
# ─────────────────────────────────────────────
# TECHNIQUE 10: CHECKPOINT RECOVERY PIPELINE  (now MULTITHREADED)
# ─────────────────────────────────────────────

def process_pipeline(
    input_excel_path: str,
    output_excel_path: str,
    checkpoint_interval: int = 10,
    max_rows: int = None,        # Set to a number like 10 to test, or None for the full file
    max_workers: int = 4,        # ADDED: number of concurrent worker threads
    stop_event: threading.Event = None,   # ADDED: cooperative stop signal from the GUI
    progress_callback=None,      # ADDED: called as progress_callback(done, total, stats)
):
    print(f"\n{'='*60}")
    print(f"Loading: {input_excel_path}")
    print(f"Output : {output_excel_path}")
    print(f"Workers: {max_workers}")
    print(f"{'='*60}\n")

    try:
        df = pd.read_excel(input_excel_path)
        if max_rows is not None:  # FIXED: Proper check for max_rows
            df = df.head(max_rows)
    except FileNotFoundError:
        print(f"ERROR: File not found: '{input_excel_path}'")
        return None

    # Define output columns
    new_cols = [
        "ADDRESS_MATCH_TYPE",
        "WEB_SEARCH_ADDRESS",
        "ADDRESS_CONFIDENCE",
        "LATITUDE",             # NEW
        "LONGITUDE",            # NEW
        "ADDRESS_JUSTIFICATION",
        "WEB_SEARCH_LINK",
    ]

    # Insert columns after LOCATION_ADDRESS if it exists
    if "LOCATION_ADDRESS" in df.columns:
        base_idx = df.columns.get_loc("LOCATION_ADDRESS") + 1
        for i, col in enumerate(new_cols):
            if col not in df.columns:
                df.insert(base_idx + i, col, None)
    else:
        for col in new_cols:
            if col in df.columns:
                df[col] = df[col].astype('object')

    print(f"Total records to process: {len(df)}\n")

    stats = {"exact": 0, "partial": 0, "not_found": 0, "skip": 0, "error": 0}

    # ── Build the worklist (checkpoint recovery: skip already-processed rows) ──
    worklist = []
    for idx, row in df.iterrows():
        # Skip already-processed rows (checkpoint recovery)
        if pd.notna(row.get("WEB_SEARCH_ADDRESS")) and \
           str(row.get("WEB_SEARCH_ADDRESS")).strip() not in ("", "None"):
            stats["skip"] += 1
            continue

        # FIXED: Safely extract variables to prevent "nan" from appearing in empty Excel cells
        issuer = str(row.get("ISSUER_NAME", "")).strip() if pd.notna(row.get("ISSUER_NAME")) else ""
        company = str(row.get("LOCATION_NAME", "")).strip() if pd.notna(row.get("LOCATION_NAME")) else ""
        city = str(row.get("CITY", "")).strip() if pd.notna(row.get("CITY")) else ""
        state = str(row.get("STATE", "")).strip() if pd.notna(row.get("STATE")) else ""
        country = str(row.get("COUNTRY", "")).strip() if pd.notna(row.get("COUNTRY")) else ""

        worklist.append((idx, issuer, company, city, state, country))

    total_to_do = len(worklist)
    print(f"Records to enrich this run: {total_to_do} (skipped already-done: {stats['skip']})\n")

    # --- NEW: Safe float conversion to prevent Pandas dtype clashes ---
    def safe_float(val):
        if not val or str(val).strip() == "":
            return None
        try:
            return float(val)
        except ValueError:
            # Fallback in case the LLM hallucinated letters (e.g., "50.92N")
            return str(val)
    # ----------------------------------------------------------------

    # Worker: does the network/LLM work only. No DataFrame writes here (thread-safe).
    def worker(item):
        idx, issuer, company, city, state, country = item
        if stop_event is not None and stop_event.is_set():
            return idx, None  # signal: skipped due to stop request

        loc_display = ", ".join([loc for loc in [city, state, country] if loc])
        tqdm.write(f"\n[{idx+1}] Issuer: {issuer!r} | Asset: {company!r} | {loc_display}")

        # FIXED: Calling the correct function name (get_address)
        response_data = get_address(issuer, company, city, state, country)
        return idx, response_data

    completed = 0
    save_lock = threading.Lock()

    # Added safety block to catch unexpected exits and save progress
    try:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(worker, item) for item in worklist]

            for fut in as_completed(futures):
                idx, response_data = fut.result()

                # Row was skipped because stop was requested before it ran
                if response_data is None:
                    continue

                # Generate the fallback URL for your spreadsheet
                row = df.loc[idx]
                issuer = str(row.get("ISSUER_NAME", "")).strip() if pd.notna(row.get("ISSUER_NAME")) else ""
                company = str(row.get("LOCATION_NAME", "")).strip() if pd.notna(row.get("LOCATION_NAME")) else ""
                city = str(row.get("CITY", "")).strip() if pd.notna(row.get("CITY")) else ""
                state = str(row.get("STATE", "")).strip() if pd.notna(row.get("STATE")) else ""
                country = str(row.get("COUNTRY", "")).strip() if pd.notna(row.get("COUNTRY")) else ""

                search_target = f"{issuer} {company}".strip()
                search_query = urllib.parse.quote(f"{search_target} {city} {state} {country} office address")
                source_link = f"https://www.google.com/search?q={search_query}"

                # Safely extract the fields directly from the native JSON object
                match_type = response_data.get("match_type", "UNKNOWN")
                address = response_data.get("address", "NOT_FOUND")
                confidence = response_data.get("confidence", "N/A")

                latitude = safe_float(response_data.get("latitude"))
                longitude = safe_float(response_data.get("longitude"))

                justification = response_data.get("justification", "Failed to extract justification.")

                tqdm.write(f"<- Match Status : [{match_type}]")
                tqdm.write(f"<- Extracted Addr: {address}")
                if latitude or longitude:
                    tqdm.write(f"<- Extracted GPS : {latitude}, {longitude}")

                # Track stats
                key = match_type.lower() if match_type.lower() in stats else "error"
                stats[key] = stats.get(key, 0) + 1

                # Commit to Dataframe
                df.at[idx, 'ADDRESS_MATCH_TYPE'] = match_type
                df.at[idx, 'WEB_SEARCH_ADDRESS'] = address
                df.at[idx, 'ADDRESS_CONFIDENCE'] = confidence
                df.at[idx, 'LATITUDE'] = latitude
                df.at[idx, 'LONGITUDE'] = longitude
                df.at[idx, 'ADDRESS_JUSTIFICATION'] = justification
                df.at[idx, 'WEB_SEARCH_LINK'] = response_data.get("source_url", source_link)

                completed += 1

                if progress_callback is not None:
                    progress_callback(completed, total_to_do, dict(stats))

                # Periodic checkpoint save (every N completed rows)
                if completed % checkpoint_interval == 0:
                    with save_lock:
                        df.to_excel(output_excel_path, index=False)
                    tqdm.write(f"   [CHECKPOINT] Saved at {completed}/{total_to_do} processed")

            if stop_event is not None and stop_event.is_set():
                print("\n[!] Stop requested — in-flight rows finished, remaining rows skipped.")

    except KeyboardInterrupt:
        print("\n[!] Script stopped manually. Saving current progress...")
    except Exception as e:
        print(f"\n[!] Unexpected error: {str(e)}. Saving current progress...")
    finally:
        df.to_excel(output_excel_path, index=False)

        print(f"\n{'='*60}")
        print(f"PIPELINE COMPLETE → {output_excel_path}")
        print(f"RESULTS SUMMARY:")
        total = len(df)
        for k, v in stats.items():
            pct = (v / total * 100) if total else 0
            print(f"  {k.upper():12s}: {v:4d}  ({pct:.1f}%)")
        print(f"{'='*60}\n")

    return stats


# ─────────────────────────────────────────────
# GUI  (Tkinter) — wraps process_pipeline, runs it on a background thread
# ─────────────────────────────────────────────

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext


# Default file names (same as the original script's entry point)
DEFAULT_INPUT = "Phase2_3_Null_assets_consolidated_P2_Batch_2_2222.xlsx"
DEFAULT_OUTPUT = "Phase2_3_Null_assets_consolidated_P2_Batch_2_2222_output.xlsx"


class _QueueWriter:
    """A file-like object that pushes everything written to it into a queue,
    so print()/tqdm.write() from the pipeline (and worker threads) show in the GUI."""
    def __init__(self, q):
        self.q = q

    def write(self, text):
        if text:
            self.q.put(("log", text))

    def flush(self):
        pass


class AddressEnricherGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Address Enrichment Pipeline — GUI (Multithreaded)")
        self.root.geometry("900x640")
        self.root.minsize(760, 560)

        self.msg_queue = queue.Queue()
        self.stop_event = threading.Event()
        self.worker_thread = None

        self._build_ui()
        self.root.after(100, self._poll_queue)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------- UI construction ----------
    def _build_ui(self):
        pad = {"padx": 8, "pady": 4}

        frm = ttk.Frame(self.root, padding=10)
        frm.pack(fill="both", expand=True)

        # Input file
        ttk.Label(frm, text="Input Excel:").grid(row=0, column=0, sticky="w", **pad)
        self.input_var = tk.StringVar(value=DEFAULT_INPUT)
        ttk.Entry(frm, textvariable=self.input_var, width=70).grid(row=0, column=1, sticky="we", **pad)
        ttk.Button(frm, text="Browse…", command=self._browse_input).grid(row=0, column=2, **pad)

        # Output file
        ttk.Label(frm, text="Output Excel:").grid(row=1, column=0, sticky="w", **pad)
        self.output_var = tk.StringVar(value=DEFAULT_OUTPUT)
        ttk.Entry(frm, textvariable=self.output_var, width=70).grid(row=1, column=1, sticky="we", **pad)
        ttk.Button(frm, text="Browse…", command=self._browse_output).grid(row=1, column=2, **pad)

        # Parameters row
        params = ttk.Frame(frm)
        params.grid(row=2, column=0, columnspan=3, sticky="we", **pad)

        ttk.Label(params, text="Threads:").pack(side="left")
        self.workers_var = tk.IntVar(value=4)
        ttk.Spinbox(params, from_=1, to=32, width=5, textvariable=self.workers_var).pack(side="left", padx=(4, 16))

        ttk.Label(params, text="Checkpoint every:").pack(side="left")
        self.checkpoint_var = tk.IntVar(value=10)
        ttk.Spinbox(params, from_=1, to=1000, width=6, textvariable=self.checkpoint_var).pack(side="left", padx=(4, 16))

        ttk.Label(params, text="Max rows (blank = all):").pack(side="left")
        self.maxrows_var = tk.StringVar(value="")
        ttk.Entry(params, textvariable=self.maxrows_var, width=8).pack(side="left", padx=(4, 16))

        # Buttons
        btns = ttk.Frame(frm)
        btns.grid(row=3, column=0, columnspan=3, sticky="we", **pad)
        self.start_btn = ttk.Button(btns, text="▶ Start", command=self._start)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(btns, text="■ Stop", command=self._stop, state="disabled")
        self.stop_btn.pack(side="left", padx=8)
        ttk.Button(btns, text="Clear log", command=self._clear_log).pack(side="left", padx=8)

        # Progress bar
        prog = ttk.Frame(frm)
        prog.grid(row=4, column=0, columnspan=3, sticky="we", **pad)
        self.progress = ttk.Progressbar(prog, mode="determinate")
        self.progress.pack(side="left", fill="x", expand=True)
        self.progress_label = ttk.Label(prog, text="0 / 0")
        self.progress_label.pack(side="left", padx=8)

        # Stats line
        self.stats_var = tk.StringVar(value="EXACT 0  |  PARTIAL 0  |  NOT_FOUND 0  |  SKIP 0  |  ERROR 0")
        ttk.Label(frm, textvariable=self.stats_var).grid(row=5, column=0, columnspan=3, sticky="w", **pad)

        # Log area
        ttk.Label(frm, text="Log:").grid(row=6, column=0, sticky="w", **pad)
        self.log = scrolledtext.ScrolledText(frm, height=18, wrap="word", state="disabled")
        self.log.grid(row=7, column=0, columnspan=3, sticky="nsew", **pad)

        frm.columnconfigure(1, weight=1)
        frm.rowconfigure(7, weight=1)

    # ---------- Button handlers ----------
    def _browse_input(self):
        path = filedialog.askopenfilename(
            title="Select input Excel",
            filetypes=[("Excel files", "*.xlsx *.xlsm *.xls"), ("All files", "*.*")],
        )
        if path:
            self.input_var.set(path)
            # Auto-suggest an output name next to the input if output is still default
            if self.output_var.get() in ("", DEFAULT_OUTPUT):
                base, ext = os.path.splitext(path)
                self.output_var.set(f"{base}_output{ext or '.xlsx'}")

    def _browse_output(self):
        path = filedialog.asksaveasfilename(
            title="Select output Excel",
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
        )
        if path:
            self.output_var.set(path)

    def _clear_log(self):
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")

    def _start(self):
        input_path = self.input_var.get().strip()
        output_path = self.output_var.get().strip()

        if not input_path or not os.path.isfile(input_path):
            messagebox.showerror("Input missing", f"Input file not found:\n{input_path}")
            return
        if not output_path:
            messagebox.showerror("Output missing", "Please choose an output file path.")
            return

        try:
            workers = int(self.workers_var.get())
            checkpoint = int(self.checkpoint_var.get())
        except (ValueError, tk.TclError):
            messagebox.showerror("Bad value", "Threads and checkpoint must be integers.")
            return

        max_rows_raw = self.maxrows_var.get().strip()
        if max_rows_raw == "":
            max_rows = None
        else:
            try:
                max_rows = int(max_rows_raw)
            except ValueError:
                messagebox.showerror("Bad value", "Max rows must be a whole number or blank.")
                return

        # Reset run state
        self.stop_event.clear()
        self.progress.configure(value=0, maximum=1)
        self.progress_label.configure(text="0 / 0")
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")

        self.worker_thread = threading.Thread(
            target=self._run_pipeline,
            args=(input_path, output_path, checkpoint, max_rows, workers),
            daemon=True,
        )
        self.worker_thread.start()

    def _stop(self):
        self.stop_event.set()
        self._append_log("\n[GUI] Stop requested. Letting in-flight rows finish…\n")
        self.stop_btn.configure(state="disabled")

    # ---------- Background runner ----------
    def _run_pipeline(self, input_path, output_path, checkpoint, max_rows, workers):
        old_out, old_err = sys.stdout, sys.stderr
        writer = _QueueWriter(self.msg_queue)
        sys.stdout = writer
        sys.stderr = writer
        try:
            process_pipeline(
                input_excel_path=input_path,
                output_excel_path=output_path,
                checkpoint_interval=checkpoint,
                max_rows=max_rows,
                max_workers=workers,
                stop_event=self.stop_event,
                progress_callback=lambda done, total, stats: self.msg_queue.put(("progress", done, total, stats)),
            )
        except Exception as e:
            self.msg_queue.put(("log", f"\n[FATAL] {e}\n"))
        finally:
            sys.stdout, sys.stderr = old_out, old_err
            self.msg_queue.put(("done", output_path))

    # ---------- Queue polling (runs on the GUI/main thread) ----------
    def _poll_queue(self):
        try:
            while True:
                msg = self.msg_queue.get_nowait()
                kind = msg[0]
                if kind == "log":
                    self._append_log(msg[1])
                elif kind == "progress":
                    _, done, total, stats = msg
                    self.progress.configure(maximum=max(total, 1), value=done)
                    self.progress_label.configure(text=f"{done} / {total}")
                    self.stats_var.set(
                        f"EXACT {stats.get('exact',0)}  |  "
                        f"PARTIAL {stats.get('partial',0)}  |  "
                        f"NOT_FOUND {stats.get('not_found',0)}  |  "
                        f"SKIP {stats.get('skip',0)}  |  "
                        f"ERROR {stats.get('error',0)}"
                    )
                elif kind == "done":
                    self._on_run_finished(msg[1])
        except queue.Empty:
            pass
        self.root.after(100, self._poll_queue)

    def _append_log(self, text):
        self.log.configure(state="normal")
        self.log.insert("end", text)
        self.log.see("end")
        self.log.configure(state="disabled")

    def _on_run_finished(self, output_path):
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self._append_log(f"\n[GUI] Finished. Output saved to:\n{output_path}\n")

    def _on_close(self):
        if self.worker_thread is not None and self.worker_thread.is_alive():
            if not messagebox.askyesno("Quit", "A run is in progress. Stop and quit?"):
                return
            self.stop_event.set()
        self.root.destroy()


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":
    root = tk.Tk()
    app = AddressEnricherGUI(root)
    root.mainloop()
