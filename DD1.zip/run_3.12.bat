@echo off
REM ============================================================
REM  Address Enrichment Pipeline - launcher (Python 3.12)
REM  Creates a local venv with Python 3.12, installs deps,
REM  then launches the GUI.
REM ============================================================

setlocal
cd /d "%~dp0"

REM --- Check that Python 3.12 is available via the py launcher ---
py -3.12 --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] Python 3.12 was not found via the "py" launcher.
    echo         Install Python 3.12 from https://www.python.org/downloads/
    echo         (make sure the "py launcher" option is checked during install)
    echo.
    pause
    exit /b 1
)

REM --- Create the virtual environment once ---
if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment with Python 3.12...
    py -3.12 -m venv .venv
    if errorlevel 1 (
        echo [ERROR] Failed to create the virtual environment.
        pause
        exit /b 1
    )
)

REM --- Activate it ---
call ".venv\Scripts\activate.bat"

REM --- Install / update dependencies ---
echo Installing dependencies...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Dependency installation failed. See messages above.
    pause
    exit /b 1
)

REM --- Launch the GUI ---
echo Launching Address Enrichment GUI...
python address_enrichment_gui.py

echo.
echo Done.
pause
endlocal
