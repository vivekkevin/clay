#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Palm-tree detection on large aerial imagery with YOLOv3 + ImageAI.

End-to-end, self-contained VS Code script. It will, on its own:
  1. Download the training/validation chips, the aerial GeoTIFF mosaic and the
     pretrained palm-tree model (Google Drive bundle first, GitHub-LFS fallback).
  2. Download the COCO YOLOv3 weights used as the transfer-learning seed.
  3. (optionally) preview a few annotated training tiles.
  4. (optionally) train a custom YOLOv3 detector.
  5. Evaluate saved models (mAP).
  6. Run detection on a small test image.
  7. Slice the big mosaic into tiles, detect palm trees on each tile, convert
     pixel boxes to map (lon/lat) coordinates and write a CSV report.
  8. Render the detections on an interactive Folium map (saved as HTML).

Original notebook by Kyaw Naing Win (2021):
  https://github.com/knwin/Detect-palmtrees-with-Yolo-and-ImageAI

Ported / hardened for local execution. See README.md for environment setup --
this pipeline needs the *legacy* (Keras/TensorFlow) ImageAI stack because the
repo's pretrained weights are `.h5`, not the PyTorch `.pt` used by ImageAI 3.x.

Usage examples
--------------
    # Do everything (downloads, optionally train, detect, map). Skips training
    # by default and uses the ready-made pretrained model so it runs fast:
    python palm_tree_detection.py

    # Force a fresh training run for N epochs:
    python palm_tree_detection.py --train --epochs 50 --batch-size 8

    # Only run the mosaic detection + map using the pretrained model:
    python palm_tree_detection.py --detect-mosaic --make-map

    # Just fetch all the data and exit:
    python palm_tree_detection.py --download-only
"""

from __future__ import annotations

import argparse
import datetime as _dt
import os
import random
import shutil
import sys
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

# --------------------------------------------------------------------------- #
#  Configuration                                                              #
# --------------------------------------------------------------------------- #

# Everything lives under this directory. The ImageAI trainer/detector expect a
# folder named "Palmtrees" containing train/, validation/, models/, json/, ...
BASE_DIR = Path(os.environ.get("PALM_BASE_DIR", ".")).resolve()
DATA_ROOT = BASE_DIR / "Palmtrees"

# --- Remote sources -------------------------------------------------------- #
# Primary: the full bundle the original notebook used, hosted on Google Drive.
# This single zip extracts into a complete "Palmtrees/" tree (train, validation,
# models seed, json, pretrained_model, python/utilities, Subset_test.JPG, tif).
GDRIVE_BUNDLE_ID = "1HemNGDOSXSYOM1bh5OrYuA88GUq3n4_k"

# Fallback: assemble the tree from the GitHub repo. NOTE: the data files in the
# repo are Git LFS pointers, so we must hit media.githubusercontent.com (which
# serves the real LFS blobs) and NOT the plain codeload zip (134-byte stubs).
GH_OWNER = "knwin"
GH_REPO = "Detect-palmtrees-with-Yolo-and-ImageAI"
GH_BRANCH = "main"


def _lfs(path: str) -> str:
    """Build a media.githubusercontent.com URL that resolves a Git LFS file."""
    return (
        f"https://media.githubusercontent.com/media/"
        f"{GH_OWNER}/{GH_REPO}/{GH_BRANCH}/{urllib.parse.quote(path)}"
    )


LFS_CHIPS_ZIP = _lfs("data/palmtree_image_chips.zip")          # 25 MB train/val
LFS_MOSAIC_TIF = _lfs("data/Kolovai UAV4R Subset.tif")         # 142 MB GeoTIFF
LFS_PALM_MODEL_ZIP = _lfs("pretrained model/palmtree_model_loss26.zip")  # 228 MB

# COCO-pretrained YOLOv3 weights for transfer learning (ImageAI release v4).
COCO_YOLOV3_URL = (
    "https://github.com/OlafenwaMoses/ImageAI/releases/download/"
    "essential-v4/pretrained-yolov3.h5"
)

# --- Key files inside DATA_ROOT ------------------------------------------- #
MOSAIC_TIF = DATA_ROOT / "Kolovai UAV4R Subset.tif"
TEST_IMAGE = DATA_ROOT / "Subset_test.JPG"
TEST_IMAGE_OUT = DATA_ROOT / "Subset_test_detected.JPG"
JSON_CONFIG = DATA_ROOT / "json" / "detection_config.json"
MODELS_DIR = DATA_ROOT / "models"
PRETRAINED_DIR = DATA_ROOT / "pretrained_model"
COCO_SEED = BASE_DIR / "pretrained-yolov3.h5"
CSV_REPORT = DATA_ROOT / "detection_report.csv"
MAP_HTML = DATA_ROOT / "detection_map.html"
PREVIEW_PNG = DATA_ROOT / "train_preview.png"

# Detection / training defaults (match the notebook).
OBJECT_NAMES = ["palm_tree"]


# --------------------------------------------------------------------------- #
#  Small utilities                                                            #
# --------------------------------------------------------------------------- #

def log(msg: str) -> None:
    print(f"[{_dt.datetime.now():%H:%M:%S}] {msg}", flush=True)


def _download(url: str, dest: Path, desc: str | None = None) -> Path:
    """Stream-download `url` to `dest` with a simple progress bar."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.stat().st_size > 1024:
        log(f"  exists, skipping: {dest.name}")
        return dest
    desc = desc or dest.name
    log(f"  downloading {desc} ...")

    def _hook(block_num, block_size, total_size):
        if total_size > 0:
            done = min(block_num * block_size, total_size)
            pct = done * 100 / total_size
            bar = "#" * int(pct // 2.5)
            sys.stdout.write(
                f"\r    {bar:<40} {pct:5.1f}%  "
                f"({done/1e6:6.1f}/{total_size/1e6:6.1f} MB)"
            )
            sys.stdout.flush()

    tmp = dest.with_suffix(dest.suffix + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req) as r, open(tmp, "wb") as f:
        total = int(r.headers.get("Content-Length", 0))
        block = 1 << 16
        n = 0
        while True:
            chunk = r.read(block)
            if not chunk:
                break
            f.write(chunk)
            n += 1
            _hook(n, block, total)
    sys.stdout.write("\n")
    tmp.rename(dest)
    return dest


def _unzip(zip_path: Path, dest: Path) -> None:
    log(f"  extracting {zip_path.name} -> {dest}")
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(dest)


# --------------------------------------------------------------------------- #
#  Stage 1: data acquisition                                                  #
# --------------------------------------------------------------------------- #

def _try_gdrive_bundle() -> bool:
    """Download + extract the full Google-Drive bundle into ./Palmtrees."""
    try:
        import gdown  # noqa: WPS433  (optional dependency)
    except ImportError:
        log("  gdown not installed -> skipping Google-Drive bundle "
            "(pip install gdown to enable it)")
        return False

    bundle = BASE_DIR / "palmtrees_bundle.zip"
    try:
        if not (bundle.exists() and bundle.stat().st_size > 1024):
            log("  downloading full Google-Drive bundle ...")
            gdown.download(id=GDRIVE_BUNDLE_ID, output=str(bundle), quiet=False)
        _unzip(bundle, BASE_DIR)
    except Exception as exc:  # noqa: BLE001
        log(f"  Google-Drive bundle failed ({exc}); will try GitHub-LFS.")
        return False

    # The bundle may extract straight to Palmtrees/ or into a subdir; normalise.
    if not DATA_ROOT.exists():
        for cand in BASE_DIR.glob("*"):
            if cand.is_dir() and (cand / "train").exists():
                cand.rename(DATA_ROOT)
                break
    return DATA_ROOT.exists() and (DATA_ROOT / "train").exists()


def _assemble_from_github_lfs() -> bool:
    """Fallback: build ./Palmtrees from the repo's Git-LFS assets."""
    log("  assembling dataset from GitHub Git-LFS assets ...")
    DATA_ROOT.mkdir(parents=True, exist_ok=True)

    # 1) Training + validation chips (Pascal-VOC) -> Palmtrees/{train,validation}
    chips_zip = BASE_DIR / "palmtree_image_chips.zip"
    _download(LFS_CHIPS_ZIP, chips_zip, "training image chips (~25 MB)")
    _unzip(chips_zip, DATA_ROOT)

    # 2) Aerial mosaic GeoTIFF
    _download(LFS_MOSAIC_TIF, MOSAIC_TIF, "aerial mosaic GeoTIFF (~142 MB)")

    # 3) Pretrained palm-tree model (.h5 + detection_config.json)
    palm_zip = BASE_DIR / "palmtree_model_loss26.zip"
    _download(LFS_PALM_MODEL_ZIP, palm_zip, "pretrained palm model (~228 MB)")
    _unzip(palm_zip, PRETRAINED_DIR)
    _normalise_pretrained_dir()

    return (DATA_ROOT / "train").exists()


def _normalise_pretrained_dir() -> None:
    """Make sure pretrained_model/ holds the .h5 and detection_config.json, and
    that json/detection_config.json exists for the detector/evaluator."""
    h5s = list(PRETRAINED_DIR.rglob("*.h5"))
    cfgs = list(PRETRAINED_DIR.rglob("detection_config.json"))
    # flatten if the zip nested everything one level deep
    for f in h5s + cfgs:
        target = PRETRAINED_DIR / f.name
        if f.resolve() != target.resolve():
            shutil.copy2(f, target)
    JSON_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    if cfgs and not JSON_CONFIG.exists():
        shutil.copy2(cfgs[0], JSON_CONFIG)


def acquire_data() -> None:
    """Ensure ./Palmtrees and the COCO seed weights are present."""
    log("STAGE 1 - acquiring data")
    if DATA_ROOT.exists() and (DATA_ROOT / "train").exists():
        log("  ./Palmtrees already present, skipping dataset download.")
    else:
        ok = _try_gdrive_bundle()
        if not ok:
            ok = _assemble_from_github_lfs()
        if not ok:
            raise RuntimeError(
                "Could not obtain the dataset from either Google Drive or "
                "GitHub-LFS. Check your internet connection / firewall."
            )

    # The big GeoTIFF may be missing if the bundle didn't include it.
    if not MOSAIC_TIF.exists():
        _download(LFS_MOSAIC_TIF, MOSAIC_TIF, "aerial mosaic GeoTIFF (~142 MB)")

    # COCO YOLOv3 seed for transfer learning.
    _download(COCO_YOLOV3_URL, COCO_SEED, "COCO YOLOv3 seed weights (~237 MB)")

    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    log("  data ready.")


# --------------------------------------------------------------------------- #
#  Stage 2: preview a few annotated training tiles (self-contained)           #
# --------------------------------------------------------------------------- #

def view_images(images_dir: Path, annotations_dir: Path,
                n: int = 4, out_png: Path = PREVIEW_PNG) -> None:
    """Re-implementation of the repo's `utilities.view_images`: overlay the
    Pascal-VOC bounding boxes onto random training tiles and save a montage."""
    import matplotlib
    matplotlib.use("Agg")  # headless / file output
    import matplotlib.pyplot as plt
    import matplotlib.patches as patches
    from PIL import Image

    imgs = sorted(p for p in images_dir.glob("*")
                  if p.suffix.lower() in {".jpg", ".jpeg", ".png"})
    if not imgs:
        log(f"  no images found in {images_dir}")
        return
    sample = random.sample(imgs, min(n, len(imgs)))

    cols = 2
    rows = (len(sample) + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(10, 5 * rows))
    axes = axes.ravel() if hasattr(axes, "ravel") else [axes]

    for ax, img_path in zip(axes, sample):
        ax.imshow(Image.open(img_path))
        ax.set_title(img_path.name, fontsize=8)
        ax.axis("off")
        xml = annotations_dir / (img_path.stem + ".xml")
        if xml.exists():
            for obj in ET.parse(xml).getroot().findall("object"):
                b = obj.find("bndbox")
                x1, y1 = int(b.find("xmin").text), int(b.find("ymin").text)
                x2, y2 = int(b.find("xmax").text), int(b.find("ymax").text)
                ax.add_patch(patches.Rectangle(
                    (x1, y1), x2 - x1, y2 - y1,
                    linewidth=1.5, edgecolor="lime", facecolor="none"))
    for ax in axes[len(sample):]:
        ax.axis("off")

    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_png, dpi=120)
    plt.close(fig)
    log(f"  saved preview montage -> {out_png}")


# --------------------------------------------------------------------------- #
#  Stage 3: training                                                          #
# --------------------------------------------------------------------------- #

def train(epochs: int, batch_size: int, seed_model: Path) -> None:
    log("STAGE 3 - training custom YOLOv3 detector")
    from imageai.Detection.Custom import DetectionModelTrainer

    trainer = DetectionModelTrainer()
    trainer.setModelTypeAsYOLOv3()
    trainer.setDataDirectory(data_directory=str(DATA_ROOT))
    trainer.setTrainConfig(
        object_names_array=OBJECT_NAMES,
        batch_size=batch_size,
        num_experiments=epochs,
        train_from_pretrained_model=str(seed_model),
    )
    log(f"  epochs={epochs}  batch_size={batch_size}  seed={seed_model.name}")
    trainer.trainModel()
    log("  training finished. Saved models are in Palmtrees/models/")


def evaluate() -> None:
    log("STAGE 4 - evaluating saved models (mAP)")
    from imageai.Detection.Custom import DetectionModelTrainer

    if not any(MODELS_DIR.glob("*.h5")):
        log("  no .h5 models found in Palmtrees/models -> skipping evaluation.")
        return
    trainer = DetectionModelTrainer()
    trainer.setModelTypeAsYOLOv3()
    trainer.setDataDirectory(data_directory=str(DATA_ROOT))
    metrics = trainer.evaluateModel(
        model_path=str(MODELS_DIR),
        json_path=str(JSON_CONFIG),
        iou_threshold=0.5,
        object_threshold=0.3,
        nms_threshold=0.5,
    )
    print(metrics)


# --------------------------------------------------------------------------- #
#  Detector construction                                                      #
# --------------------------------------------------------------------------- #

def _latest_trained_model() -> Path | None:
    models = sorted(MODELS_DIR.glob("*.h5"))
    return models[-1] if models else None


def _pretrained_palm_model() -> tuple[Path | None, Path | None]:
    """Return (model_path, json_path) for the ready-made palm-tree model."""
    h5s = sorted(PRETRAINED_DIR.glob("*.h5"))
    cfg = PRETRAINED_DIR / "detection_config.json"
    if not cfg.exists():
        cfg = JSON_CONFIG if JSON_CONFIG.exists() else None
    return (h5s[-1] if h5s else None), cfg


def build_detector(use_pretrained: bool):
    """Construct a loaded CustomObjectDetection. Prefer a freshly trained model;
    otherwise fall back to the supplied pretrained palm-tree model."""
    from imageai.Detection.Custom import CustomObjectDetection

    model_path = json_path = None
    if not use_pretrained:
        model_path = _latest_trained_model()
        json_path = JSON_CONFIG if JSON_CONFIG.exists() else None
    if model_path is None or json_path is None:
        model_path, json_path = _pretrained_palm_model()

    if model_path is None or json_path is None:
        raise FileNotFoundError(
            "No usable model/json pair found. Train first (--train) or make "
            "sure the pretrained model downloaded into Palmtrees/pretrained_model."
        )

    log(f"  loading detector: {model_path.name}")
    detector = CustomObjectDetection()
    detector.setModelTypeAsYOLOv3()
    detector.setModelPath(str(model_path))
    detector.setJsonPath(str(json_path))
    detector.loadModel()
    return detector


# --------------------------------------------------------------------------- #
#  Stage 5: quick detection on the small test image                           #
# --------------------------------------------------------------------------- #

def test_detect(detector, min_prob: int = 20) -> None:
    log("STAGE 5 - detection on the small test image")
    if not TEST_IMAGE.exists():
        log(f"  {TEST_IMAGE.name} not found -> skipping single-image test.")
        return
    detections = detector.detectObjectsFromImage(
        input_image=str(TEST_IMAGE),
        output_image_path=str(TEST_IMAGE_OUT),
        minimum_percentage_probability=min_prob,
    )
    for d in detections:
        print(f"  {d['name']} : {d['percentage_probability']:.1f} : {d['box_points']}")
    log(f"  annotated image saved -> {TEST_IMAGE_OUT}")


# --------------------------------------------------------------------------- #
#  Stage 6: detection across the big georeferenced mosaic                     #
# --------------------------------------------------------------------------- #

def pixel_to_map(px: float, py: float, gt) -> tuple[float, float]:
    """Convert pixel (col,row) to map (x,y) using a GDAL geotransform."""
    mx = gt[0] + px * gt[1] + py * gt[2]
    my = gt[3] + px * gt[4] + py * gt[5]
    return mx, my


def detect_mosaic(detector, image_path: Path, chip_h: int, chip_w: int,
                  prob_threshold: int, csv_name: Path) -> None:
    log("STAGE 6 - sliding-window detection across the mosaic")
    import numpy as np
    import rasterio  # bundles GDAL in its wheels (pip-installable, no conda)

    if not image_path.exists():
        raise FileNotFoundError(f"Mosaic not found: {image_path}")

    with rasterio.open(str(image_path)) as ds:
        gt = ds.transform.to_gdal()      # GDAL-style geotransform tuple
        arr = ds.read()                  # (bands, H, W)

    # (bands, H, W) -> (H, W, bands); keep RGB then flip to BGR for the detector.
    arr = np.moveaxis(arr, 0, -1)[..., :3]
    arr = np.flip(arr, 2)
    h, w, _ = arr.shape

    # Pad so the image divides evenly into chips.
    pad_right = (chip_w - w % chip_w) % chip_w
    pad_bottom = (chip_h - h % chip_h) % chip_h
    # NOTE: the original notebook padded the width axis with `pad_bottom`
    # (a bug). Fixed here to use pad_right on axis 1.
    arr = np.pad(arr, ((0, pad_bottom), (0, pad_right), (0, 0)),
                 mode="constant", constant_values=0)
    h, w, _ = arr.shape
    rows = np.arange(0, h, chip_h)
    cols = np.arange(0, w, chip_w)

    log(f"  mosaic {w}x{h}px -> {len(rows)*len(cols)} tiles "
        f"({chip_w}x{chip_h}); prob>={prob_threshold}%")
    obj_count = 0
    csv_name.parent.mkdir(parents=True, exist_ok=True)
    with open(csv_name, "w") as f:
        f.write("object,probability,lon,lat,width,height,aspect_ratio,area\n")
        for row in rows:
            for col in cols:
                tile = arr[row:row + chip_h, col:col + chip_w, :]
                detections = detector.detectObjectsFromImage(
                    input_image=tile,
                    input_type="array",
                    output_image_path="_tmp_tile.jpg",
                    minimum_percentage_probability=prob_threshold,
                )
                obj_count += len(detections)
                sys.stdout.write(f"\r    objects detected: {obj_count}")
                sys.stdout.flush()
                for d in detections:
                    x1, y1, x2, y2 = d["box_points"]
                    x0, y0 = (x1 + x2) / 2.0, (y1 + y2) / 2.0
                    bw, bh = abs(x1 - x2), abs(y1 - y2)
                    aspect = min(bw, bh) / max(bw, bh) if max(bw, bh) else 0
                    mx, my = pixel_to_map(x0 + col, y0 + row, gt)
                    f.write(
                        f"{d['name']},{d['percentage_probability']},"
                        f"{mx},{my},{bw},{bh},{aspect},{bw*bh}\n"
                    )
    sys.stdout.write("\n")
    if Path("_tmp_tile.jpg").exists():
        Path("_tmp_tile.jpg").unlink()
    log(f"  detection report saved -> {csv_name}")


# --------------------------------------------------------------------------- #
#  Stage 7: interactive Folium map                                            #
# --------------------------------------------------------------------------- #

def make_map(image_path: Path, csv_name: Path, out_html: Path,
             aspect_ratio_threshold: float = 0.5,
             probability_threshold: float = 0.0) -> None:
    log("STAGE 7 - rendering Folium map")
    import numpy as np
    import pandas as pd
    import folium
    from folium import raster_layers
    import rasterio
    from PIL import Image

    if not csv_name.exists():
        log(f"  {csv_name.name} not found -> run --detect-mosaic first.")
        return

    with rasterio.open(str(image_path)) as ds:
        gt = ds.transform.to_gdal()
        arr = np.moveaxis(ds.read(), 0, -1)[..., :3]

    # Overlay only a manageable subset of the (huge) mosaic.
    w = h = 5000
    resampling = 5
    px1, py1 = 10000, 7000
    px2, py2 = px1 + w, py1 + h
    H, W = arr.shape[0], arr.shape[1]
    px2, py2 = min(px2, W), min(py2, H)
    lon1, lat1 = pixel_to_map(px1, py1, gt)
    lon2, lat2 = pixel_to_map(px2, py2, gt)

    subset = arr[py1:py2, px1:px2, :]
    if subset.size:
        sub_img = Image.fromarray(subset)
        new = (max(1, (px2 - px1) // resampling), max(1, (py2 - py1) // resampling))
        subset = np.array(sub_img.resize(new))

    fmap = folium.Map(location=[(lat1 + lat2) / 2, (lon1 + lon2) / 2],
                      zoom_start=18)
    folium.TileLayer(
        tiles="https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}",
        attr="Google", name="Google Satellite",
        overlay=False, control=True,
    ).add_to(fmap)
    if subset.size:
        fmap.add_child(raster_layers.ImageOverlay(
            name="subset image", image=subset, opacity=0.8,
            bounds=[[lat1, lon1], [lat2, lon2]]))

    df = pd.read_csv(csv_name)
    kept = 0
    for _, r in df.iterrows():
        if r["aspect_ratio"] >= aspect_ratio_threshold and \
           r["probability"] > probability_threshold:
            folium.Circle(radius=3, location=[r["lat"], r["lon"]],
                          color="crimson", fill=False).add_to(fmap)
            kept += 1
    out_html.parent.mkdir(parents=True, exist_ok=True)
    fmap.save(str(out_html))
    log(f"  plotted {kept}/{len(df)} detections; map saved -> {out_html}")


# --------------------------------------------------------------------------- #
#  Orchestration                                                              #
# --------------------------------------------------------------------------- #

def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="End-to-end palm-tree detection (YOLOv3 + ImageAI).",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    # Stage switches. If none of the "action" stages are given, a sensible
    # default pipeline runs (download -> preview -> [pretrained] detect -> map).
    p.add_argument("--download-only", action="store_true",
                   help="only fetch data + weights, then exit")
    p.add_argument("--preview", action="store_true",
                   help="save a montage of annotated training tiles")
    p.add_argument("--train", action="store_true",
                   help="train a custom model (else use the pretrained one)")
    p.add_argument("--evaluate", action="store_true",
                   help="compute mAP of saved models")
    p.add_argument("--test-detect", action="store_true",
                   help="run detection on the small test image")
    p.add_argument("--detect-mosaic", action="store_true",
                   help="run sliding-window detection over the GeoTIFF mosaic")
    p.add_argument("--make-map", action="store_true",
                   help="render the Folium map from the CSV report")

    # Hyper-parameters / knobs.
    p.add_argument("--epochs", type=int, default=5,
                   help="training epochs (use 30-50 for a good model)")
    p.add_argument("--batch-size", type=int, default=8,
                   help="training batch size (larger = better but more RAM)")
    p.add_argument("--seed-model", type=str, default=str(COCO_SEED),
                   help="transfer-learning seed (.h5)")
    p.add_argument("--use-pretrained", action="store_true",
                   help="force using the ready-made palm model for detection")
    p.add_argument("--chip", type=int, default=448, help="tile size (px)")
    p.add_argument("--prob-threshold", type=int, default=25,
                   help="min %% probability during mosaic detection")
    p.add_argument("--test-prob", type=int, default=20,
                   help="min %% probability for the test image")
    p.add_argument("--aspect-threshold", type=float, default=0.5,
                   help="map filter: min bbox aspect ratio (0-1)")
    p.add_argument("--map-prob", type=float, default=0.0,
                   help="map filter: min probability (0-100)")
    return p.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)
    log(f"Working directory : {BASE_DIR}")
    log(f"Dataset directory : {DATA_ROOT}")

    # --- Stage 1 always: make sure data is present. ---------------------- #
    acquire_data()
    if args.download_only:
        log("download-only requested; done.")
        return 0

    # Decide whether we're in "default full run" mode.
    explicit = any([args.preview, args.train, args.evaluate, args.test_detect,
                    args.detect_mosaic, args.make_map])
    default_run = not explicit

    # --- Preview ---------------------------------------------------------- #
    if args.preview or default_run:
        view_images(DATA_ROOT / "train" / "images",
                    DATA_ROOT / "train" / "annotations")

    # --- Train / evaluate ------------------------------------------------- #
    use_pretrained = args.use_pretrained or (not args.train)
    if args.train:
        train(args.epochs, args.batch_size, Path(args.seed_model))
        use_pretrained = False
    if args.evaluate:
        evaluate()

    # Build a detector only if a detection stage will run.
    need_detector = (args.test_detect or args.detect_mosaic or default_run)
    detector = build_detector(use_pretrained) if need_detector else None

    # --- Detection stages ------------------------------------------------- #
    if args.test_detect or default_run:
        test_detect(detector, min_prob=args.test_prob)

    if args.detect_mosaic or default_run:
        detect_mosaic(detector, MOSAIC_TIF, args.chip, args.chip,
                      args.prob_threshold, CSV_REPORT)

    # --- Map -------------------------------------------------------------- #
    if args.make_map or default_run:
        make_map(MOSAIC_TIF, CSV_REPORT, MAP_HTML,
                 aspect_ratio_threshold=args.aspect_threshold,
                 probability_threshold=args.map_prob)

    log("All requested stages complete.")
    log(f"  CSV : {CSV_REPORT}")
    log(f"  Map : {MAP_HTML}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
