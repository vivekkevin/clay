# Palm Survey Console (web GUI)

A small web dashboard for the palm-tree aerial-detection pipeline
(`palm_tree_detection.py`). It runs each pipeline stage, streams the live
console output to your browser, and shows the results — detection map, report
table, annotated test image, and training-tile preview.

**No npm, no Express, no internet packages.** The server is a single Node.js
file with zero dependencies. You only need Node.js installed.

## Put these three files together

Create a folder named **`webapp`** and put all three files in it, side by side
(no sub-folders):

```
webapp\
├── start.bat
├── server.js
└── page.html
```

Then put that `webapp` folder right next to your project files:

```
Plam\
├── palm_tree_detection.py
├── requirements.txt
├── palm\            (your Python 3.8 venv)
├── Palmtrees\       (pipeline outputs)
└── webapp\          <-- the three files above
```

The server finds the project automatically (one folder up). To use a different
location, set `PALM_PROJECT_DIR` to the folder holding `palm_tree_detection.py`.

## Run

Double-click **`start.bat`**. It checks Node.js, makes sure the Python venv and
`requirements.txt` are installed, starts the server, and opens
**http://localhost:5050**. Leave the window open while using it; close it (or
press Ctrl+C) to stop.

> Needs **Node.js** (any current LTS) and **Python 3.8** with the project's
> requirements. If `start.bat` says Node is missing, install the LTS build from
> https://nodejs.org/ and run it again.

## Controls → pipeline stages

| Button | Flag | Does |
|---|---|---|
| Run full survey | *(default)* | data → preview → test image → mosaic → map |
| 01 Get imagery & model | `--download-only` | fetch images, GeoTIFF, pretrained model |
| 02 Preview training tiles | `--preview` | montage of annotated training chips |
| 03 Train detector | `--train` | transfer-learn YOLOv3 (slow on CPU) |
| 04 Validate (mAP) | `--evaluate` | score trained models |
| 05 Detect on test image | `--test-detect` | detection on the small test image |
| 06 Scan full mosaic | `--detect-mosaic` | tile the GeoTIFF and detect across it |
| 07 Build detection map | `--make-map` | render the interactive map from the CSV |

The **Parameters** drawer sets confidence thresholds, tile size, and training
epochs/batch. One run at a time; **Stop run** cancels it. The big number tracks
palms detected live, mirroring the terminal counter.

## Results tabs

- **Map** — embeds `Palmtrees\detection_map.html`
- **Aerial view** — a Leaflet map that overlays the GeoTIFF with the detections
  drawn on top. Click *Load aerial imagery* for a fast downsampled overlay, or
  tick **Full resolution** to stream native-resolution map tiles straight from
  the GeoTIFF (read on demand with rasterio, so you can zoom to full detail
  without loading the whole 142 MB image). Hover the imagery to see its
  attribution; the opacity slider fades imagery against the detections.
- **Report** — stats, confidence histogram, first 500 rows of `detection_report.csv`
- **Test image** — `Palmtrees\Subset_test_detected.JPG`
- **Training tiles** — `Palmtrees\train_preview.png`

The Aerial view needs the GeoTIFF present (it ships in the data bundle) and uses
the `rasterio` already in `requirements.txt`. Internet is required the first time
so the browser can load Leaflet from its CDN.

## Notes

- Detection uses the bundled pretrained model, so you get full results without
  training. Training/validate are included for completeness but need a GPU
  TensorFlow build to be practical.
- Change the port with the `PORT` environment variable (default 5050).
- If the page header shows a warning that the script can't be found, the
  `webapp` folder isn't next to `palm_tree_detection.py` — move it, or set
  `PALM_PROJECT_DIR`.
