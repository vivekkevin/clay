/* ------------------------------------------------------------------ *
 * Palm Survey Console - single-file server, ZERO npm dependencies.
 * Needs only Node.js. Place next to start.bat and page.html, inside a
 * "webapp" folder that sits beside palm_tree_detection.py.
 * Run:  node server.js     (start.bat does this for you)
 * ------------------------------------------------------------------ */
"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const url = require("url");
const { spawn } = require("child_process");

const PORT = process.env.PORT || 5050;

const PROJECT_DIR = path.resolve(
  process.env.PALM_PROJECT_DIR || path.join(__dirname, "..")
);
const SCRIPT = path.join(PROJECT_DIR, "palm_tree_detection.py");
const PALMTREES = path.join(PROJECT_DIR, "Palmtrees");
const PAGE = path.join(__dirname, "page.html");

function resolvePython() {
  if (process.env.PALM_PYTHON) return process.env.PALM_PYTHON;
  const win = process.platform === "win32";
  const cands = win
    ? [path.join(PROJECT_DIR, "palm", "Scripts", "python.exe"),
       path.join(PROJECT_DIR, ".venv", "Scripts", "python.exe"), "python"]
    : [path.join(PROJECT_DIR, "palm", "bin", "python"),
       path.join(PROJECT_DIR, ".venv", "bin", "python"), "python3"];
  for (const c of cands) {
    if (c === "python" || c === "python3") return c;
    if (fs.existsSync(c)) return c;
  }
  return cands[cands.length - 1];
}
const PYTHON = resolvePython();

const OUT = {
  preview: "train_preview.png",
  testImage: "Subset_test_detected.JPG",
  map: "detection_map.html",
  report: "detection_report.csv",
};
const MOSAIC_TIF_NAME = "Kolovai UAV4R Subset.tif";

// Embedded Python (run with the project's venv) that downsamples the full
// GeoTIFF to a web JPEG and writes its WGS84 bounds for a Leaflet overlay.
const OVERLAY_PY = [
  "import os, json",
  "import numpy as np",
  "import rasterio",
  "from rasterio.enums import Resampling",
  "from PIL import Image",
  "tif = os.path.join('Palmtrees', 'Kolovai UAV4R Subset.tif')",
  "with rasterio.open(tif) as ds:",
  "    W, H = ds.width, ds.height",
  "    gt = ds.transform.to_gdal()",
  "    scale = max(1.0, max(W, H) / 4000.0)",
  "    ow, oh = max(1, int(round(W / scale))), max(1, int(round(H / scale)))",
  "    count = min(3, ds.count)",
  "    data = ds.read(indexes=list(range(1, count + 1)), out_shape=(count, oh, ow), resampling=Resampling.average)",
  "    if count == 1:",
  "        data = np.repeat(data, 3, axis=0)",
  "    arr = np.moveaxis(data[:3], 0, -1)",
  "if arr.dtype != np.uint8:",
  "    a = arr.astype('float32'); mx = float(a.max()) or 1.0",
  "    arr = np.clip(a / mx * 255.0, 0, 255).astype('uint8')",
  "def p2m(px, py): return (gt[0] + px*gt[1] + py*gt[2], gt[3] + px*gt[4] + py*gt[5])",
  "lon0, lat0 = p2m(0, 0); lon1, lat1 = p2m(W, H)",
  "south, north = min(lat0, lat1), max(lat0, lat1)",
  "west, east = min(lon0, lon1), max(lon0, lon1)",
  "Image.fromarray(arr).save(os.path.join('Palmtrees', 'mosaic_web.jpg'), quality=85)",
  "json.dump({'bounds': [[south, west], [north, east]], 'attribution': 'Aerial imagery \\u00a9 OpenAerialMap contributors', 'width': ow, 'height': oh}, open(os.path.join('Palmtrees', 'mosaic_web.json'), 'w'))",
  "print('overlay ready', ow, oh)",
].join("\n");

// Fast metadata read: WGS84 bounds + a sensible native max zoom for tiling.
const INFO_PY = [
  "import os, json, math, rasterio",
  "tif = os.path.join('Palmtrees', 'Kolovai UAV4R Subset.tif')",
  "with rasterio.open(tif) as ds:",
  "    W, H = ds.width, ds.height",
  "    gt = ds.transform.to_gdal()",
  "def p2m(px, py): return (gt[0] + px*gt[1] + py*gt[2], gt[3] + px*gt[4] + py*gt[5])",
  "lon0, lat0 = p2m(0, 0); lon1, lat1 = p2m(W, H)",
  "south, north = min(lat0, lat1), max(lat0, lat1)",
  "west, east = min(lon0, lon1), max(lon0, lon1)",
  "R = 20037508.342789244",
  "def mx(lon): return R * lon / 180.0",
  "gsd = abs(mx(east) - mx(west)) / max(1, W)",
  "maxz = int(round(math.log2((R * 2) / (gsd * 256)))) if gsd > 0 else 20",
  "maxz = max(1, min(24, maxz))",
  "json.dump({'bounds': [[south, west], [north, east]], 'maxzoom': maxz, 'minzoom': max(1, maxz - 9), 'attribution': 'Aerial imagery \\u00a9 OpenAerialMap contributors'}, open(os.path.join('Palmtrees', 'tiles_info.json'), 'w'))",
  "print('info ok', maxz)",
].join("\n");

// Persistent worker: reads "z x y" lines on stdin, returns one PNG tile each,
// reprojected to Web Mercator on the fly. Frame: "OK <len>\\n"+bytes, or "EMPTY\\n".
const TILER_PY = [
  "import sys, os, io",
  "import numpy as np",
  "import rasterio",
  "from rasterio.warp import reproject, transform_bounds",
  "from rasterio.transform import from_bounds as tfb",
  "from rasterio.enums import Resampling",
  "from PIL import Image",
  "R = 20037508.342789244",
  "tif = os.path.join('Palmtrees', 'Kolovai UAV4R Subset.tif')",
  "src = rasterio.open(tif)",
  "nb = min(3, src.count)",
  "s_minx, s_miny, s_maxx, s_maxy = transform_bounds(src.crs, 'EPSG:3857', *src.bounds)",
  "def tile_bounds(z, x, y):",
  "    n = 2 ** z; ts = 2 * R / n",
  "    return (-R + x*ts, R - (y+1)*ts, -R + (x+1)*ts, R - y*ts)",
  "out = sys.stdout.buffer",
  "sys.stderr.write('tiler ready\\n'); sys.stderr.flush()",
  "for line in sys.stdin:",
  "    line = line.strip()",
  "    if not line: continue",
  "    try:",
  "        z, x, y = [int(v) for v in line.split()]",
  "        minx, miny, maxx, maxy = tile_bounds(z, x, y)",
  "        if maxx <= s_minx or minx >= s_maxx or maxy <= s_miny or miny >= s_maxy:",
  "            out.write(b'EMPTY\\n'); out.flush(); continue",
  "        dst_transform = tfb(minx, miny, maxx, maxy, 256, 256)",
  "        dst = np.zeros((nb, 256, 256), 'uint8')",
  "        reproject(source=rasterio.band(src, tuple(range(1, nb + 1))), destination=dst, dst_transform=dst_transform, dst_crs='EPSG:3857', resampling=Resampling.bilinear, dst_nodata=0)",
  "        xs = minx + (np.arange(256) + 0.5) * (maxx - minx) / 256.0",
  "        ys = maxy - (np.arange(256) + 0.5) * (maxy - miny) / 256.0",
  "        inx = (xs >= s_minx) & (xs <= s_maxx); iny = (ys >= s_miny) & (ys <= s_maxy)",
  "        alpha = (iny[:, None] & inx[None, :]).astype('uint8') * 255",
  "        if int(alpha.max()) == 0:",
  "            out.write(b'EMPTY\\n'); out.flush(); continue",
  "        rgb = np.repeat(dst, 3, axis=0) if nb == 1 else dst[:3]",
  "        rgba = np.dstack([np.moveaxis(rgb, 0, -1).astype('uint8'), alpha])",
  "        buf = io.BytesIO(); Image.fromarray(rgba, 'RGBA').save(buf, 'PNG'); b = buf.getvalue()",
  "        out.write(b'OK ' + str(len(b)).encode() + b'\\n'); out.write(b); out.flush()",
  "    except Exception as e:",
  "        sys.stderr.write('tile err ' + str(e) + '\\n'); sys.stderr.flush()",
  "        out.write(b'EMPTY\\n'); out.flush()",
].join("\n");

const TRANSPARENT_PNG = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
  "base64"
);

// --- persistent tile worker management ---
let tiler = null, tilerBuf = Buffer.alloc(0), tilerQueue = [];
function startTiler() {
  const tif = path.join(PALMTREES, MOSAIC_TIF_NAME);
  if (!fs.existsSync(tif)) return null;
  const p = spawn(PYTHON, ["-u", "-c", TILER_PY], { cwd: PROJECT_DIR });
  tiler = p; tilerBuf = Buffer.alloc(0);
  p.stdout.on("data", onTilerData);
  p.stderr.on("data", () => {});
  const drop = () => { while (tilerQueue.length) tilerQueue.shift().reject(new Error("tiler stopped")); tiler = null; };
  p.on("close", drop); p.on("error", drop);
  return p;
}
function onTilerData(chunk) {
  tilerBuf = Buffer.concat([tilerBuf, chunk]);
  while (true) {
    const nl = tilerBuf.indexOf(0x0a);
    if (nl < 0) break;
    const header = tilerBuf.slice(0, nl).toString("ascii").trim();
    if (header === "EMPTY") {
      tilerBuf = tilerBuf.slice(nl + 1);
      const job = tilerQueue.shift(); if (job) job.resolve(null);
    } else if (header.startsWith("OK ")) {
      const len = parseInt(header.slice(3), 10);
      const start = nl + 1;
      if (tilerBuf.length < start + len) break;
      const png = tilerBuf.slice(start, start + len);
      tilerBuf = tilerBuf.slice(start + len);
      const job = tilerQueue.shift(); if (job) job.resolve(png);
    } else {
      tilerBuf = tilerBuf.slice(nl + 1); // ignore stray line
    }
  }
}
function getTile(z, x, y) {
  return new Promise((resolve, reject) => {
    if (!tiler && !startTiler()) return reject(new Error("no GeoTIFF"));
    tilerQueue.push({ resolve, reject });
    tiler.stdin.write(z + " " + x + " " + y + "\n");
  });
}

function clampInt(v, lo, hi, dflt) {
  const n = parseInt(v, 10);
  if (Number.isNaN(n)) return dflt;
  return Math.min(hi, Math.max(lo, n));
}

function buildArgs(stage, q) {
  const prob = clampInt(q.prob, 1, 99, 25);
  const chip = clampInt(q.chip, 64, 1024, 448);
  const testProb = clampInt(q.testProb, 1, 99, 20);
  const epochs = clampInt(q.epochs, 1, 500, 20);
  const batch = clampInt(q.batch, 1, 64, 8);
  const mapProb = clampInt(q.mapProb, 0, 99, 0);
  switch (stage) {
    case "full": return ["--prob-threshold", prob, "--chip", chip, "--test-prob", testProb];
    case "download": return ["--download-only"];
    case "preview": return ["--preview"];
    case "train": return ["--train", "--epochs", epochs, "--batch-size", batch];
    case "evaluate": return ["--evaluate"];
    case "test": return ["--test-detect", "--use-pretrained", "--test-prob", testProb];
    case "mosaic": return ["--detect-mosaic", "--use-pretrained", "--chip", chip, "--prob-threshold", prob];
    case "map": return ["--make-map", "--map-prob", mapProb];
    default: return null;
  }
}

let currentProc = null;
let currentStage = null;

function summariseReport(file) {
  const text = fs.readFileSync(file, "utf8").trim();
  const lines = text.split(/\r?\n/);
  const header = lines.shift().split(",");
  const idx = (n) => header.indexOf(n);
  const pi = idx("probability"), loni = idx("lon"), lati = idx("lat");
  const ai = idx("area"), ari = idx("aspect_ratio");
  const rows = [];
  let sum = 0, min = Infinity, max = -Infinity;
  const buckets = { "25-40": 0, "40-55": 0, "55-70": 0, "70-85": 0, "85-100": 0 };
  for (const line of lines) {
    if (!line) continue;
    const c = line.split(",");
    const prob = parseFloat(c[pi]);
    if (!Number.isNaN(prob)) {
      sum += prob; min = Math.min(min, prob); max = Math.max(max, prob);
      if (prob < 40) buckets["25-40"]++;
      else if (prob < 55) buckets["40-55"]++;
      else if (prob < 70) buckets["55-70"]++;
      else if (prob < 85) buckets["70-85"]++;
      else buckets["85-100"]++;
    }
    rows.push({
      probability: prob,
      lon: parseFloat(c[loni]), lat: parseFloat(c[lati]),
      area: ai >= 0 ? parseFloat(c[ai]) : null,
      aspect: ari >= 0 ? parseFloat(c[ari]) : null,
    });
  }
  const total = rows.length;
  return {
    total,
    avgProb: total ? +(sum / total).toFixed(1) : 0,
    minProb: total ? +min.toFixed(1) : 0,
    maxProb: total ? +max.toFixed(1) : 0,
    buckets, rows: rows.slice(0, 500),
  };
}

function sendJSON(res, obj, code = 200) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { "Content-Type": "application/json" });
  res.end(body);
}

const MIME = {
  ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
  ".html": "text/html", ".csv": "text/csv", ".json": "application/json",
};

function serveOutput(res, name) {
  const safe = path.basename(name);
  const file = path.join(PALMTREES, safe);
  if (!fs.existsSync(file)) { res.writeHead(404); return res.end("not found"); }
  res.writeHead(200, { "Content-Type": MIME[path.extname(safe).toLowerCase()] || "application/octet-stream" });
  fs.createReadStream(file).pipe(res);
}

function servePage(res) {
  let html;
  try { html = fs.readFileSync(PAGE, "utf8"); }
  catch (e) {
    res.writeHead(500, { "Content-Type": "text/plain" });
    return res.end("Cannot read page.html next to server.js (" + e.message + ")");
  }
  const banner = fs.existsSync(SCRIPT) ? "" :
    '<div class="banner banner-warn">Could not find <code>palm_tree_detection.py</code> in <code>' +
    PROJECT_DIR + '</code>. Set <code>PALM_PROJECT_DIR</code> to the folder that holds the script, then restart.</div>';
  html = html.split("__PROJECT_DIR__").join(PROJECT_DIR)
             .split("__PYTHON__").join(PYTHON)
             .split("__SCRIPT_BANNER__").join(banner);
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  res.end(html);
}

function killTree(proc) {
  try {
    if (process.platform === "win32") spawn("taskkill", ["/pid", String(proc.pid), "/T", "/F"]);
    else proc.kill("SIGTERM");
  } catch (_) {}
}

function startStream(res, stage, q) {
  const args = buildArgs(stage, q);
  if (!args) { res.writeHead(400); return res.end("unknown stage"); }
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no",
  });
  const send = (event, data) => res.write("event: " + event + "\ndata: " + JSON.stringify(data) + "\n\n");

  if (currentProc) { send("error", "Another run is already in progress."); return res.end(); }
  if (!fs.existsSync(SCRIPT)) { send("error", "Cannot find palm_tree_detection.py in " + PROJECT_DIR); return res.end(); }

  const fullArgs = ["-u", SCRIPT, ...args.map(String)];
  send("start", { stage, cmd: PYTHON + " " + fullArgs.join(" ") });

  const proc = spawn(PYTHON, fullArgs, { cwd: PROJECT_DIR });
  currentProc = proc; currentStage = stage;
  const startedAt = Date.now();

  const handle = (chunk) => {
    const parts = chunk.toString("utf8").split(/\r\n|\r|\n/);
    for (const raw of parts) {
      const line = raw.replace(/\s+$/, "");
      if (line === "") continue;
      send("log", line);
      let m;
      if ((m = line.match(/objects detected:\s*(\d+)/i))) send("count", parseInt(m[1], 10));
      if ((m = line.match(/->\s*(\d+)\s*tiles/i))) send("tiles", parseInt(m[1], 10));
      if ((m = line.match(/STAGE\s+\d+\s*-\s*(.+)$/i))) send("phase", m[1].trim());
    }
  };
  proc.stdout.on("data", handle);
  proc.stderr.on("data", handle);
  proc.on("close", (code) => {
    send("done", { code, seconds: ((Date.now() - startedAt) / 1000).toFixed(1) });
    currentProc = null; currentStage = null; res.end();
  });
  proc.on("error", (err) => {
    send("error", String(err)); currentProc = null; currentStage = null; res.end();
  });
}

const server = http.createServer((req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname;

  if (pathname === "/" ) return servePage(res);

  if (pathname === "/api/status") {
    const exists = (f) => fs.existsSync(path.join(PALMTREES, f));
    const st = {
      running: !!currentProc, stage: currentStage,
      have: { preview: exists(OUT.preview), testImage: exists(OUT.testImage), map: exists(OUT.map), report: exists(OUT.report) },
      models: [], detections: null,
    };
    const md = path.join(PALMTREES, "models");
    if (fs.existsSync(md)) st.models = fs.readdirSync(md).filter((f) => f.endsWith(".h5")).sort();
    if (st.have.report) { try { st.detections = summariseReport(path.join(PALMTREES, OUT.report)).total; } catch (_) {} }
    return sendJSON(res, st);
  }

  if (pathname === "/api/report") {
    const file = path.join(PALMTREES, OUT.report);
    if (!fs.existsSync(file)) return sendJSON(res, { ok: false, reason: "no report yet" });
    try { return sendJSON(res, Object.assign({ ok: true }, summariseReport(file))); }
    catch (e) { return sendJSON(res, { ok: false, reason: String(e) }); }
  }

  if (pathname === "/api/stop" && req.method === "POST") {
    if (currentProc) killTree(currentProc);
    return sendJSON(res, { ok: true });
  }

  if (pathname === "/api/build-overlay") {
    const tif = path.join(PALMTREES, MOSAIC_TIF_NAME);
    const jpg = path.join(PALMTREES, "mosaic_web.jpg");
    const meta = path.join(PALMTREES, "mosaic_web.json");
    if (!fs.existsSync(tif))
      return sendJSON(res, { ok: false, reason: "GeoTIFF not found in Palmtrees — run the data download first." });
    try {
      if (fs.existsSync(jpg) && fs.existsSync(meta) &&
          fs.statSync(jpg).mtimeMs >= fs.statSync(tif).mtimeMs) {
        const m = JSON.parse(fs.readFileSync(meta, "utf8"));
        return sendJSON(res, Object.assign({ ok: true, cached: true, img: "/outputs/mosaic_web.jpg" }, m));
      }
    } catch (_) {}
    const proc = spawn(PYTHON, ["-c", OVERLAY_PY], { cwd: PROJECT_DIR });
    let err = "";
    proc.stderr.on("data", (d) => (err += d.toString()));
    proc.stdout.on("data", () => {});
    proc.on("close", (code) => {
      if (code === 0 && fs.existsSync(meta)) {
        try {
          const m = JSON.parse(fs.readFileSync(meta, "utf8"));
          return sendJSON(res, Object.assign({ ok: true, img: "/outputs/mosaic_web.jpg" }, m));
        } catch (e) { return sendJSON(res, { ok: false, reason: String(e) }); }
      }
      const tail = err.split(/\r?\n/).filter(Boolean).slice(-3).join(" | ");
      return sendJSON(res, { ok: false, reason: tail || ("python exited " + code) });
    });
    proc.on("error", (e) => sendJSON(res, { ok: false, reason: String(e) }));
    return;
  }

  if (pathname === "/api/points") {
    const file = path.join(PALMTREES, OUT.report);
    if (!fs.existsSync(file)) return sendJSON(res, { ok: false, reason: "no report yet" });
    try {
      const text = fs.readFileSync(file, "utf8").trim();
      const lines = text.split(/\r?\n/);
      const header = lines.shift().split(",");
      const pi = header.indexOf("probability"), loni = header.indexOf("lon"), lati = header.indexOf("lat");
      const pts = [];
      for (const line of lines) {
        if (!line) continue;
        const c = line.split(",");
        const lat = parseFloat(c[lati]), lon = parseFloat(c[loni]), p = parseFloat(c[pi]);
        if (!Number.isNaN(lat) && !Number.isNaN(lon))
          pts.push([+lat.toFixed(7), +lon.toFixed(7), Math.round(p || 0)]);
      }
      return sendJSON(res, { ok: true, points: pts });
    } catch (e) { return sendJSON(res, { ok: false, reason: String(e) }); }
  }

  if (pathname === "/api/tiles-info") {
    const tif = path.join(PALMTREES, MOSAIC_TIF_NAME);
    const info = path.join(PALMTREES, "tiles_info.json");
    if (!fs.existsSync(tif))
      return sendJSON(res, { ok: false, reason: "GeoTIFF not found — run the data download first." });
    try {
      if (fs.existsSync(info) && fs.statSync(info).mtimeMs >= fs.statSync(tif).mtimeMs)
        return sendJSON(res, Object.assign({ ok: true }, JSON.parse(fs.readFileSync(info, "utf8"))));
    } catch (_) {}
    const proc = spawn(PYTHON, ["-c", INFO_PY], { cwd: PROJECT_DIR });
    let err = "";
    proc.stderr.on("data", (d) => (err += d.toString()));
    proc.stdout.on("data", () => {});
    proc.on("close", (code) => {
      if (code === 0 && fs.existsSync(info)) {
        try { return sendJSON(res, Object.assign({ ok: true }, JSON.parse(fs.readFileSync(info, "utf8")))); }
        catch (e) { return sendJSON(res, { ok: false, reason: String(e) }); }
      }
      return sendJSON(res, { ok: false, reason: err.split(/\r?\n/).filter(Boolean).slice(-2).join(" | ") || ("exit " + code) });
    });
    proc.on("error", (e) => sendJSON(res, { ok: false, reason: String(e) }));
    return;
  }

  if (pathname.startsWith("/tiles/")) {
    const m = pathname.match(/^\/tiles\/(\d+)\/(\d+)\/(\d+)(?:\.png)?$/);
    if (!m) { res.writeHead(404); return res.end(); }
    getTile(+m[1], +m[2], +m[3])
      .then((png) => {
        res.writeHead(200, { "Content-Type": "image/png", "Cache-Control": "max-age=3600" });
        res.end(png || TRANSPARENT_PNG);
      })
      .catch(() => { res.writeHead(200, { "Content-Type": "image/png" }); res.end(TRANSPARENT_PNG); });
    return;
  }

  if (pathname.startsWith("/stream/")) {
    return startStream(res, pathname.slice("/stream/".length), parsed.query);
  }

  if (pathname.startsWith("/outputs/")) {
    return serveOutput(res, decodeURIComponent(pathname.slice("/outputs/".length)));
  }

  res.writeHead(404, { "Content-Type": "text/plain" });
  res.end("not found");
});

server.listen(PORT, () => {
  console.log("\n  Palm Survey Console:  http://localhost:" + PORT + "\n");
  console.log("  Project : " + PROJECT_DIR);
  console.log("  Python  : " + PYTHON);
  console.log("  Script  : " + SCRIPT + " (" + (fs.existsSync(SCRIPT) ? "found" : "MISSING") + ")\n");
});
