@echo off
setlocal enableextensions
title Palm Survey Console

REM ====================================================================
REM  One-click launcher for the Palm Survey web console.
REM  Put these three files together in a folder named "webapp":
REM      webapp\start.bat   webapp\server.js   webapp\page.html
REM  and put that "webapp" folder next to palm_tree_detection.py.
REM  No npm / no internet packages needed for the web server itself.
REM ====================================================================

set "WEBAPP=%~dp0"
pushd "%WEBAPP%.."
set "PROJECT=%CD%"
popd

echo ============================================================
echo   Palm Survey Console
echo   Project folder : %PROJECT%
echo ============================================================
echo.

REM --- 0. The two app files must sit next to this .bat ---------------
if not exist "%WEBAPP%server.js" (
  echo [X] server.js is missing from this folder:
  echo     %WEBAPP%
  echo     Save server.js and page.html into the SAME folder as start.bat.
  echo.
  pause
  exit /b 1
)
if not exist "%WEBAPP%page.html" (
  echo [X] page.html is missing from this folder:
  echo     %WEBAPP%
  echo     Save page.html next to server.js and start.bat.
  echo.
  pause
  exit /b 1
)

REM --- 1. Node.js present? ------------------------------------------
where node >nul 2>nul
if errorlevel 1 (
  echo [X] Node.js was not found on your PATH.
  echo     Install the LTS build from https://nodejs.org/ and run this again.
  echo.
  pause
  exit /b 1
)

REM --- 2. Python venv + requirements --------------------------------
set "VENV=%PROJECT%\palm"
set "VPY=%VENV%\Scripts\python.exe"
if not exist "%VPY%" (
  echo [*] Creating Python 3.8 environment at %VENV% ...
  py -3.8 -m venv "%VENV%"
  if errorlevel 1 (
    echo [X] Could not create the environment. Check Python 3.8:  py -3.8 --version
    pause
    exit /b 1
  )
)
if exist "%PROJECT%\requirements.txt" (
  echo [*] Checking Python packages ...
  "%VPY%" -m pip install --upgrade pip >nul
  "%VPY%" -m pip install -r "%PROJECT%\requirements.txt"
  if errorlevel 1 (
    echo [X] pip install failed - scroll up to see the conflicting package.
    pause
    exit /b 1
  )
) else (
  echo [!] requirements.txt not found in %PROJECT% - skipping Python install.
)

REM --- 3. Launch (no npm needed) ------------------------------------
set "PALM_PROJECT_DIR=%PROJECT%"
set "PALM_PYTHON=%VPY%"
echo.
echo [*] Starting console at http://localhost:5050
echo     Leave this window open while you use it. Close it (or Ctrl+C) to stop.
echo.
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 3; Start-Process 'http://localhost:5050'"
node "%WEBAPP%server.js"

endlocal
