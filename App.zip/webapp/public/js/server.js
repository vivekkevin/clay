/* ------------------------------------------------------------------ *
 * Palm Survey Console - Express/EJS front-end for the palm-tree
 * aerial-detection pipeline (palm_tree_detection.py).
 *
 * It runs each pipeline stage as a child process of the project's
 * Python venv, streams the live output to the browser over SSE, and
 * serves/parses the results (annotated image, map, CSV report).
 * ------------------------------------------------------------------ */
"use strict";

const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");
const express = require("express");

const app = express();
const PORT = process.env.PORT || 5050;

// --- Locate the project (where palm_tree_detection.py lives) -------- //
// Defaults to the parent folder of this webapp; override with PALM_PROJECT_DIR.
const PROJECT_DIR = path.resolve(
  process.env.PALM_PROJECT_DIR || path.join(__dirname, "..")
);
const SCRIPT = path.join(PROJECT_DIR, "palm_tree_detection.py");
const PALMTREES = path.join(PROJECT_DIR, "Palmtrees");

// Prefer the venv's python; fall back to system python.
function resolvePython() {
  if (process.env.PALM_PYTHON) return process.env.PALM_PYTHON;
  const candidates =
    process.platform === "win32"
      ? [
          path.join(PROJECT_DIR, "palm", "Scripts", "python.exe"),
          path.join(PROJECT_DIR, ".venv", "Scripts", "python.exe"),
          "python",
        ]
      : [
          path.join(PROJECT_DIR, "palm", "bin", "python"),
          path.join(PROJECT_DIR, ".venv", "bin", "python"),
          "python3",
        ];
  for (const c of candidates) {
    if (c === "python" || c === "python3") return c;
    if (fs.existsSync(c)) return c;
  }
  return candidates[candidates.length - 1];
}
const PYTHON = resolvePython();

const OUTPUTS = {
  preview: "train_preview.png",
  testImage: "Subset_test_detected.JPG",
  map: "detection_map.html",
  report: "detection_report.csv",
};

// --- Stage definitions: which flags each button runs --------------- //
function buildArgs(stage, q) {
  const prob = clampInt(q.prob, 1, 99, 25);
  const chip = clampInt(q.chip, 64, 1024, 448);
  const testProb = clampInt(q.testProb, 1, 99, 20);
  const epochs = clampInt(q.epochs, 1, 500, 20);
  const batch = clampInt(q.batch, 1, 64, 8);
  const mapProb = clampInt(q.mapProb, 0, 99, 0);

  switch (stage) {
    case "full":
      return ["--prob-threshold", prob, "--chip", chip, "--test-prob", testProb];
    case "download":
      return ["--download-only"];
    case "preview":
      return ["--preview"];
    case "train":
      return ["--train", "--epochs", epochs, "--batch-size", batch];
    case "evaluate":
      return ["--evaluate"];
    case "test":
      return ["--test-detect", "--use-pretrained", "--test-prob", testProb];
    case "mosaic":
      return [
        "--detect-mosaic", "--use-pretrained",
        "--chip", chip, "--prob-threshold", prob,
      ];
    case "map":
      return ["--make-map", "--map-prob", mapProb];
    default:
      return null;
  }
}

function clampInt(v, lo, hi, dflt) {
  const n = parseInt(v, 10);
  if (Number.isNaN(n)) return dflt;
  return Math.min(hi, Math.max(lo, n));
}

// --- One run at a time --------------------------------------------- //
let currentProc = null;
let currentStage = null;

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use("/static", express.static(path.join(__dirname, "public")));
app.use("/outputs", express.static(PALMTREES));

app.get("/", (req, res) => {
  res.render("index", {
    python: PYTHON,
    projectDir: PROJECT_DIR,
    scriptExists: fs.existsSync(SCRIPT),
    outputs: OUTPUTS,
  });
});

// Which result files currently exist + headline numbers.
app.get("/api/status", (req, res) => {
  const exists = (f) => fs.existsSync(path.join(PALMTREES, f));
  const status = {
    running: !!currentProc,
    stage: currentStage,
    have: {
      preview: exists(OUTPUTS.preview),
      testImage: exists(OUTPUTS.testImage),
      map: exists(OUTPUTS.map),
      report: exists(OUTPUTS.report),
    },
    models: [],
    detections: null,
  };
  // List trained models if any.
  const modelsDir = path.join(PALMTREES, "models");
  if (fs.existsSync(modelsDir)) {
    status.models = fs
      .readdirSync(modelsDir)
      .filter((f) => f.endsWith(".h5"))
      .sort();
  }
  if (status.have.report) {
    try {
      status.detections = summariseReport(
        path.join(PALMTREES, OUTPUTS.report)
      ).total;
    } catch (_) {}
  }
  res.json(status);
});

// Parsed detection report: summary stats + rows.
app.get("/api/report", (req, res) => {
  const file = path.join(PALMTREES, OUTPUTS.report);
  if (!fs.existsSync(file)) return res.json({ ok: false, reason: "no report yet" });
  try {
    res.json({ ok: true, ...summariseReport(file) });
  } catch (e) {
    res.json({ ok: false, reason: String(e) });
  }
});

function summariseReport(file) {
  const text = fs.readFileSync(file, "utf8").trim();
  const lines = text.split(/\r?\n/);
  const header = lines.shift().split(",");
  const idx = (name) => header.indexOf(name);
  const pi = idx("probability"), loni = idx("lon"), lati = idx("lat");
  const ai = idx("area"), ari = idx("aspect_ratio");

  const rows = [];
  let probSum = 0, probMin = Infinity, probMax = -Infinity;
  const buckets = { "25-40": 0, "40-55": 0, "55-70": 0, "70-85": 0, "85-100": 0 };
  for (const line of lines) {
    if (!line) continue;
    const c = line.split(",");
    const prob = parseFloat(c[pi]);
    if (!Number.isNaN(prob)) {
      probSum += prob;
      probMin = Math.min(probMin, prob);
      probMax = Math.max(probMax, prob);
      if (prob < 40) buckets["25-40"]++;
      else if (prob < 55) buckets["40-55"]++;
      else if (prob < 70) buckets["55-70"]++;
      else if (prob < 85) buckets["70-85"]++;
      else buckets["85-100"]++;
    }
    rows.push({
      probability: prob,
      lon: parseFloat(c[loni]),
      lat: parseFloat(c[lati]),
      area: ai >= 0 ? parseFloat(c[ai]) : null,
      aspect: ari >= 0 ? parseFloat(c[ari]) : null,
    });
  }
  const total = rows.length;
  return {
    total,
    avgProb: total ? +(probSum / total).toFixed(1) : 0,
    minProb: total ? +probMin.toFixed(1) : 0,
    maxProb: total ? +probMax.toFixed(1) : 0,
    buckets,
    rows: rows.slice(0, 500), // cap payload
  };
}

// Stop the active run.
app.post("/api/stop", (req, res) => {
  if (!currentProc) return res.json({ ok: true, note: "nothing running" });
  killTree(currentProc);
  res.json({ ok: true });
});

// SSE: start a stage and stream its output.
app.get("/stream/:stage", (req, res) => {
  const stage = req.params.stage;
  const args = buildArgs(stage, req.query);
  if (!args) return res.status(400).end("unknown stage");

  res.set({
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no",
  });
  res.flushHeaders();

  const send = (event, data) =>
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);

  if (currentProc) {
    send("error", "Another run is already in progress.");
    return res.end();
  }
  if (!fs.existsSync(SCRIPT)) {
    send("error", `Cannot find palm_tree_detection.py in ${PROJECT_DIR}`);
    return res.end();
  }

  const fullArgs = ["-u", SCRIPT, ...args.map(String)];
  send("start", { stage, cmd: `${PYTHON} ${fullArgs.join(" ")}` });

  const proc = spawn(PYTHON, fullArgs, { cwd: PROJECT_DIR });
  currentProc = proc;
  currentStage = stage;
  const startedAt = Date.now();

  const handle = (chunk) => {
    // Split on CR and LF so the "\r objects detected: N" counter updates live.
    const parts = chunk.toString("utf8").split(/\r\n|\r|\n/);
    for (const raw of parts) {
      const line = raw.replace(/\s+$/, "");
      if (line === "") continue;
      send("log", line);
      const m = line.match(/objects detected:\s*(\d+)/i);
      if (m) send("count", parseInt(m[1], 10));
      const t = line.match(/->\s*(\d+)\s*tiles/i);
      if (t) send("tiles", parseInt(t[1], 10));
      const s = line.match(/STAGE\s+\d+\s*-\s*(.+)$/i);
      if (s) send("phase", s[1].trim());
    }
  };
  proc.stdout.on("data", handle);
  proc.stderr.on("data", handle);

  proc.on("close", (code) => {
    const secs = ((Date.now() - startedAt) / 1000).toFixed(1);
    send("done", { code, seconds: secs });
    currentProc = null;
    currentStage = null;
    res.end();
  });
  proc.on("error", (err) => {
    send("error", String(err));
    currentProc = null;
    currentStage = null;
    res.end();
  });

  req.on("close", () => {
    // Browser disconnected: leave the run going only if it's the long mosaic;
    // otherwise stop it to avoid orphans. Here we keep it running so a page
    // refresh doesn't kill a long scan, but the proc handle is cleared on close.
  });
});

function killTree(proc) {
  try {
    if (process.platform === "win32") {
      spawn("taskkill", ["/pid", String(proc.pid), "/T", "/F"]);
    } else {
      proc.kill("SIGTERM");
    }
  } catch (_) {}
}

app.listen(PORT, () => {
  console.log(`\n  Palm Survey Console running:  http://localhost:${PORT}\n`);
  console.log(`  Project : ${PROJECT_DIR}`);
  console.log(`  Python  : ${PYTHON}`);
  console.log(`  Script  : ${SCRIPT} (${fs.existsSync(SCRIPT) ? "found" : "MISSING"})\n`);
});
