# Palm-tree detection on aerial imagery — VS Code edition (no conda)

An end-to-end, self-contained port of Kyaw Naing Win's Colab notebook
([knwin/Detect-palmtrees-with-Yolo-and-ImageAI](https://github.com/knwin/Detect-palmtrees-with-Yolo-and-ImageAI))
to a single runnable Python script. It downloads everything it needs, trains
(optionally) or uses a ready-made model, detects palm trees across a large
georeferenced aerial mosaic, writes a CSV report, and renders an interactive
map — no notebook and **no Anaconda/conda** required.

## What the script does

`palm_tree_detection.py` runs these stages:

1. **Download** training/validation chips, the aerial GeoTIFF, and the
   pretrained palm-tree model. Primary source is the original Google-Drive
   bundle (via `gdown`); if that fails it rebuilds the dataset from the GitHub
   **Git-LFS** assets.
2. **Download** the COCO YOLOv3 weights used as the transfer-learning seed.
3. **Preview** a few annotated training tiles -> `Palmtrees/train_preview.png`.
4. **Train** a custom YOLOv3 detector (optional).
5. **Evaluate** saved models (mAP, optional).
6. **Detect** on a small test image -> `Palmtrees/Subset_test_detected.JPG`.
7. **Detect** across the big mosaic by tiling it, converting pixel boxes to
   lon/lat, and writing `Palmtrees/detection_report.csv`.
8. **Map** the detections -> `Palmtrees/detection_map.html`.

## Important environment note (read first)

**Use Python 3.8.** This pipeline needs the *legacy* Keras/TensorFlow ImageAI
(`.h5` weights). The current ImageAI 3.x is PyTorch-based (`.pt`) and cannot
load these weights, and TensorFlow 2.4 does not support Python 3.9+.

You do **not** need conda. GDAL is avoided entirely — the script reads the
GeoTIFF with `rasterio`, whose Windows wheels already bundle GDAL, so a plain
`pip install` works.

## Setup (Windows, plain venv — no conda)

1. Install **Python 3.8** for Windows from python.org (the 3.8.10 installer is
   the last 3.8 build). During install, tick **"Add Python to PATH"**.
2. In PowerShell, from the folder containing these files:

```powershell
py -3.8 -m venv palm
palm\Scripts\activate
python -m pip install -U pip
pip install -r requirements.txt
```

Your prompt should now show `(palm)`. If activation is blocked by an execution
policy, run once:
`Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` and try again.

> TensorFlow on Windows needs the Microsoft Visual C++ 2015-2019 Redistributable
> (x64). Most machines already have it; if TF fails to import, install it from
> Microsoft and retry.

(Linux/macOS is the same idea: `python3.8 -m venv palm && source palm/bin/activate && pip install -r requirements.txt`.)

## Run

```powershell
# Default: download everything, preview, detect with the ready-made model,
# run mosaic detection, and build the map. (Skips training -> fast.)
python palm_tree_detection.py

# Train your own model first (use 30-50 epochs for a good one):
python palm_tree_detection.py --train --epochs 50 --batch-size 8

# Only the mosaic detection + map, reusing the pretrained model:
python palm_tree_detection.py --detect-mosaic --make-map --use-pretrained

# Just fetch the data and exit:
python palm_tree_detection.py --download-only
```

Useful flags: `--epochs`, `--batch-size`, `--chip` (tile size, default 448),
`--prob-threshold` (mosaic detection %), `--aspect-threshold` / `--map-prob`
(map filters). See `python palm_tree_detection.py --help` for all options.

Everything is written under `./Palmtrees/`. Override the parent directory with
the `PALM_BASE_DIR` environment variable.

## Outputs

| File | Description |
|------|-------------|
| `Palmtrees/train_preview.png` | montage of annotated training tiles |
| `Palmtrees/models/*.h5` | models saved during training |
| `Palmtrees/Subset_test_detected.JPG` | test image with detections drawn |
| `Palmtrees/detection_report.csv` | per-detection class, probability, lon/lat, box size |
| `Palmtrees/detection_map.html` | interactive Folium map of detections |

## Notes

- The full download is large (~142 MB GeoTIFF, ~25 MB chips, ~228 MB pretrained
  model, ~237 MB COCO seed). Training on CPU is very slow; use a GPU if you can.
- Two notebook bugs are fixed here: the mosaic padding now pads the width axis
  correctly, and the detection probability-threshold parameter is wired through
  properly.

## Credits

Original work and data by **Kyaw Naing Win**. Detection framework: **ImageAI**
by Moses Olafenwa. Aerial imagery: **OpenAerialMap**.
