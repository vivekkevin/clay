@echo off
REM ============================================================
REM  Address & Geo Enrichment Pipeline - Launcher
REM  - Creates a local virtual environment (first run only)
REM  - Installs dependencies
REM  - Launches the GUI
REM ============================================================
setlocal
cd /d "%~dp0"

REM --- Find Python ---
where python >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python was not found on PATH.
    echo Install Python 3.10+ from https://www.python.org/downloads/
    echo and tick "Add Python to PATH" during setup.
    pause
    exit /b 1
)

REM --- Create venv on first run ---
if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    python -m venv .venv
    if %ERRORLEVEL% NEQ 0 (
        echo [ERROR] Could not create virtual environment.
        pause
        exit /b 1
    )
)

set "PY=.venv\Scripts\python.exe"

REM --- Install / update dependencies ---
echo Installing dependencies (first run may take a minute)...
"%PY%" -m pip install --upgrade pip >nul
"%PY%" -m pip install -r requirements.txt
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Dependency installation failed. Check your internet connection.
    pause
    exit /b 1
)

REM --- Launch GUI ---
echo Launching GUI...
"%PY%" gui_app.py

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [!] The application exited with an error. See messages above.
    pause
)
endlocal
