"""
gui_app.py
==================================================================
Address & Geo Enrichment - DESKTOP GUI
==================================================================
A Tkinter front-end that lets you:
  - Upload an input .xlsx / .csv
  - Configure workers, checkpoint interval, engine (processes/threads)
  - Override the LLM endpoint / key / model
  - Run the enrichment with a live progress bar + log
  - Resume safely (already-enriched rows are skipped)
  - Stop at any time without losing progress (checkpoint save)

Parallelism uses concurrent.futures so the same code path drives both a
ProcessPoolExecutor (true multiprocessing — default, as requested) and a
ThreadPoolExecutor. Work here is network-bound (search + scrape + LLM),
so many workers give a large speed-up.

The heavy logic lives in enrichment_core (importable, side-effect free),
which is essential for Windows 'spawn' multiprocessing.
"""

import os
import sys
import queue
import threading
import traceback
import multiprocessing
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import pandas as pd

import enrichment_core as core


# ──────────────────────────────────────────────────────────────────
# Column resolution (handles real-world header variations)
# ──────────────────────────────────────────────────────────────────
COLUMN_ALIASES = {
    "issuer":     ["ISSUER_NAME", "ISSUER", "PARENT_ISSUER", "PARENT", "COMPANY_GROUP"],
    "company":    ["LOCATION_NAME", "ASSET_NAME", "COMPANY_NAME", "COMPANY", "NAME", "ASSET"],
    "city":       ["CITY", "TOWN", "DISTRICT"],
    "state":      ["STATE", "PROVINCE", "REGION"],
    "country":    ["COUNTRY", "NATION"],
    "source_url": ["SOURCE_URL", "URL", "WEBSITE", "WEB_SEARCH_LINK", "LINK"],
}

OUTPUT_COLS = [
    "ADDRESS_MATCH_TYPE", "WEB_SEARCH_ADDRESS", "ADDRESS_CONFIDENCE",
    "LATITUDE", "LONGITUDE", "ADDRESS_JUSTIFICATION", "WEB_SEARCH_LINK",
]


def resolve_columns(df: pd.DataFrame) -> dict:
    """Map logical fields -> actual df column name (case-insensitive)."""
    lower = {c.lower().strip(): c for c in df.columns}
    mapping = {}
    for key, aliases in COLUMN_ALIASES.items():
        found = None
        for alias in aliases:
            if alias.lower() in lower:
                found = lower[alias.lower()]
                break
        mapping[key] = found
    return mapping


# ──────────────────────────────────────────────────────────────────
# Coordinator (runs in a background thread, drives the worker pool)
# ──────────────────────────────────────────────────────────────────
class Coordinator(threading.Thread):
    def __init__(self, params, msg_queue, stop_event):
        super().__init__(daemon=True)
        self.p = params
        self.q = msg_queue
        self.stop_event = stop_event

    def log(self, text):
        self.q.put(("log", text))

    def run(self):
        try:
            self._run()
        except Exception as e:
            self.log(f"[FATAL] {e}")
            self.log(traceback.format_exc())
            self.q.put(("done", {"error": str(e)}))

    def _load_dataframe(self, in_path, out_path, max_rows):
        # Resume: prefer the existing output file so prior work is preserved.
        load_path = out_path if os.path.exists(out_path) else in_path
        if load_path.lower().endswith(".csv"):
            df = pd.read_csv(load_path)
        else:
            df = pd.read_excel(load_path)
        if max_rows:
            df = df.head(max_rows).copy()
        for col in OUTPUT_COLS:
            if col not in df.columns:
                df[col] = None
        return df

    def _save(self, df, out_path):
        tmp = out_path + ".tmp"
        if out_path.lower().endswith(".csv"):
            df.to_csv(tmp, index=False)
        else:
            df.to_excel(tmp, index=False)
        os.replace(tmp, out_path)  # atomic-ish save, never leaves a half-written file

    def _run(self):
        p = self.p
        self.log("=" * 58)
        self.log(f"Input : {p['input']}")
        self.log(f"Output: {p['output']}")
        self.log(f"Engine: {p['engine']}  |  Workers: {p['workers']}")
        self.log("=" * 58)

        df = self._load_dataframe(p["input"], p["output"], p["max_rows"])
        cols = resolve_columns(df)
        self.log(f"Detected columns: {{ {', '.join(f'{k}->{v}' for k,v in cols.items())} }}")

        if not cols["company"] and not cols["issuer"]:
            self.log("[ERROR] Could not find an issuer/company/asset column. Check headers.")
            self.q.put(("done", {"error": "No name column found"}))
            return

        # Build the task list (skip already-enriched rows for resume support).
        tasks = []
        skipped = 0
        for idx, row in df.iterrows():
            existing = row.get("WEB_SEARCH_ADDRESS")
            if pd.notna(existing) and core.clean_str(existing) not in ("", "None", "NOT_FOUND"):
                skipped += 1
                continue
            rec = {
                "_idx": idx,
                "issuer":     row.get(cols["issuer"])     if cols["issuer"]     else "",
                "company":    row.get(cols["company"])    if cols["company"]    else "",
                "city":       row.get(cols["city"])       if cols["city"]       else "",
                "state":      row.get(cols["state"])      if cols["state"]      else "",
                "country":    row.get(cols["country"])    if cols["country"]    else "",
                "source_url": row.get(cols["source_url"]) if cols["source_url"] else "",
            }
            tasks.append(rec)

        total = len(tasks)
        self.q.put(("total", total))
        self.log(f"Total rows: {len(df)} | To process: {total} | Already done: {skipped}")
        if total == 0:
            self.log("Nothing to process. All rows already enriched.")
            self.q.put(("done", {"stats": {}}))
            return

        stats = {"exact": 0, "partial": 0, "not_found": 0, "unknown": 0,
                 "skip": 0, "error": 0}
        worker_cfg = p["worker_config"]

        Executor = ProcessPoolExecutor if p["engine"] == "Processes" else ThreadPoolExecutor
        done = 0
        checkpoint = max(1, int(p["checkpoint"]))

        try:
            with Executor(max_workers=int(p["workers"]),
                          initializer=core.init_worker,
                          initargs=(worker_cfg,)) as ex:
                future_map = {ex.submit(core.enrich_record, t): t["_idx"] for t in tasks}

                for fut in as_completed(future_map):
                    if self.stop_event.is_set():
                        self.log("[STOP] Cancelling remaining tasks...")
                        for f in future_map:
                            f.cancel()
                        break

                    idx = future_map[fut]
                    try:
                        res = fut.result()
                    except Exception as e:
                        res = {"_idx": idx, "match_type": "ERROR",
                               "address": "Future Failed", "confidence": "NONE",
                               "latitude": None, "longitude": None,
                               "justification": f"{e}", "source_url": ""}

                    self._commit(df, res)

                    mt = str(res.get("match_type", "UNKNOWN")).lower()
                    stats[mt] = stats.get(mt, 0) + 1
                    done += 1

                    name = core.clean_str(df.at[idx, cols["company"]]) if cols["company"] else f"row {idx}"
                    lat, lon = res.get("latitude"), res.get("longitude")
                    geo = f" | GPS {lat},{lon}" if (lat and lon) else ""
                    self.log(f"[{done}/{total}] {name[:42]} -> {res.get('match_type')}{geo}")

                    self.q.put(("progress", done))

                    if done % checkpoint == 0:
                        self._save(df, p["output"])
                        self.log(f"   [CHECKPOINT] saved at {done}/{total}")
        finally:
            self._save(df, p["output"])
            self.log("=" * 58)
            self.log(f"SAVED -> {p['output']}")
            denom = max(done, 1)
            for k, v in stats.items():
                if v:
                    self.log(f"  {k.upper():11s}: {v:4d} ({v/denom*100:.1f}%)")
            self.log("=" * 58)

        self.q.put(("done", {"stats": stats, "output": p["output"]}))

    def _commit(self, df, res):
        idx = res["_idx"]
        df.at[idx, "ADDRESS_MATCH_TYPE"] = res.get("match_type")
        df.at[idx, "WEB_SEARCH_ADDRESS"] = res.get("address")
        df.at[idx, "ADDRESS_CONFIDENCE"] = res.get("confidence")
        lat, lon = res.get("latitude"), res.get("longitude")
        df.at[idx, "LATITUDE"] = float(lat) if lat else None
        df.at[idx, "LONGITUDE"] = float(lon) if lon else None
        df.at[idx, "ADDRESS_JUSTIFICATION"] = res.get("justification")
        df.at[idx, "WEB_SEARCH_LINK"] = res.get("source_url")


# ──────────────────────────────────────────────────────────────────
# GUI
# ──────────────────────────────────────────────────────────────────
class App:
    def __init__(self, root):
        self.root = root
        root.title("Address & Geo Enrichment Pipeline")
        root.geometry("820x680")
        root.minsize(760, 600)

        self.msg_queue = queue.Queue()
        self.stop_event = threading.Event()
        self.coordinator = None
        self.total = 0

        self._build_ui()
        self.root.after(120, self._poll_queue)

    # ---- UI construction ----
    def _build_ui(self):
        pad = {"padx": 8, "pady": 4}

        # Files
        f_files = ttk.LabelFrame(self.root, text="Files")
        f_files.pack(fill="x", padx=10, pady=6)

        self.in_var = tk.StringVar()
        self.out_var = tk.StringVar()

        ttk.Label(f_files, text="Input  (.xlsx/.csv):").grid(row=0, column=0, sticky="w", **pad)
        ttk.Entry(f_files, textvariable=self.in_var, width=66).grid(row=0, column=1, **pad)
        ttk.Button(f_files, text="Browse...", command=self._browse_input).grid(row=0, column=2, **pad)

        ttk.Label(f_files, text="Output (.xlsx/.csv):").grid(row=1, column=0, sticky="w", **pad)
        ttk.Entry(f_files, textvariable=self.out_var, width=66).grid(row=1, column=1, **pad)
        ttk.Button(f_files, text="Browse...", command=self._browse_output).grid(row=1, column=2, **pad)

        # Run settings
        f_run = ttk.LabelFrame(self.root, text="Run Settings")
        f_run.pack(fill="x", padx=10, pady=6)

        self.workers_var = tk.IntVar(value=min(8, (os.cpu_count() or 4) * 2))
        self.checkpoint_var = tk.IntVar(value=10)
        self.maxrows_var = tk.StringVar(value="")
        self.engine_var = tk.StringVar(value="Processes")

        ttk.Label(f_run, text="Workers:").grid(row=0, column=0, sticky="w", **pad)
        ttk.Spinbox(f_run, from_=1, to=64, textvariable=self.workers_var, width=6).grid(row=0, column=1, sticky="w", **pad)

        ttk.Label(f_run, text="Checkpoint every:").grid(row=0, column=2, sticky="w", **pad)
        ttk.Spinbox(f_run, from_=1, to=1000, textvariable=self.checkpoint_var, width=6).grid(row=0, column=3, sticky="w", **pad)

        ttk.Label(f_run, text="Max rows (blank=all):").grid(row=0, column=4, sticky="w", **pad)
        ttk.Entry(f_run, textvariable=self.maxrows_var, width=8).grid(row=0, column=5, sticky="w", **pad)

        ttk.Label(f_run, text="Engine:").grid(row=1, column=0, sticky="w", **pad)
        ttk.Combobox(f_run, textvariable=self.engine_var, values=["Processes", "Threads"],
                     width=12, state="readonly").grid(row=1, column=1, sticky="w", **pad)
        ttk.Label(f_run, text="(Processes = true multiprocessing; Threads = lighter, fewer OS limits)").grid(
            row=1, column=2, columnspan=4, sticky="w", **pad)

        # LLM settings
        f_llm = ttk.LabelFrame(self.root, text="LLM Endpoint")
        f_llm.pack(fill="x", padx=10, pady=6)

        self.key_var = tk.StringVar(value=core.DEFAULT_CONFIG["api_key"])
        self.base_var = tk.StringVar(value=core.DEFAULT_CONFIG["base_url"])
        self.model_var = tk.StringVar(value=core.DEFAULT_CONFIG["model"])

        ttk.Label(f_llm, text="API Key:").grid(row=0, column=0, sticky="w", **pad)
        ttk.Entry(f_llm, textvariable=self.key_var, width=40, show="*").grid(row=0, column=1, **pad)
        ttk.Label(f_llm, text="Model:").grid(row=0, column=2, sticky="w", **pad)
        ttk.Entry(f_llm, textvariable=self.model_var, width=26).grid(row=0, column=3, **pad)

        ttk.Label(f_llm, text="Base URL:").grid(row=1, column=0, sticky="w", **pad)
        ttk.Entry(f_llm, textvariable=self.base_var, width=70).grid(row=1, column=1, columnspan=3, sticky="w", **pad)

        # Controls
        f_ctrl = ttk.Frame(self.root)
        f_ctrl.pack(fill="x", padx=10, pady=6)
        self.start_btn = ttk.Button(f_ctrl, text="Start", command=self._start)
        self.start_btn.pack(side="left", padx=4)
        self.stop_btn = ttk.Button(f_ctrl, text="Stop", command=self._stop, state="disabled")
        self.stop_btn.pack(side="left", padx=4)
        self.open_btn = ttk.Button(f_ctrl, text="Open Output Folder", command=self._open_folder, state="disabled")
        self.open_btn.pack(side="left", padx=4)

        # Progress
        self.progress = ttk.Progressbar(self.root, mode="determinate")
        self.progress.pack(fill="x", padx=10, pady=4)
        self.status_var = tk.StringVar(value="Idle.")
        ttk.Label(self.root, textvariable=self.status_var).pack(anchor="w", padx=12)

        # Log
        f_log = ttk.LabelFrame(self.root, text="Log")
        f_log.pack(fill="both", expand=True, padx=10, pady=6)
        self.log_box = tk.Text(f_log, height=14, wrap="word", state="disabled",
                               bg="#101418", fg="#d6e2ec", insertbackground="#d6e2ec")
        self.log_box.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(f_log, command=self.log_box.yview)
        sb.pack(side="right", fill="y")
        self.log_box.config(yscrollcommand=sb.set)

    # ---- actions ----
    def _browse_input(self):
        path = filedialog.askopenfilename(
            title="Select input file",
            filetypes=[("Spreadsheets", "*.xlsx *.xls *.csv"), ("All files", "*.*")])
        if path:
            self.in_var.set(path)
            base, ext = os.path.splitext(path)
            self.out_var.set(f"{base}_output{ext}")

    def _browse_output(self):
        path = filedialog.asksaveasfilename(
            title="Select output file", defaultextension=".xlsx",
            filetypes=[("Excel", "*.xlsx"), ("CSV", "*.csv")])
        if path:
            self.out_var.set(path)

    def _log(self, text):
        self.log_box.config(state="normal")
        self.log_box.insert("end", text + "\n")
        self.log_box.see("end")
        self.log_box.config(state="disabled")

    def _start(self):
        in_path = self.in_var.get().strip()
        out_path = self.out_var.get().strip()
        if not in_path or not os.path.exists(in_path):
            messagebox.showerror("Error", "Please choose a valid input file.")
            return
        if not out_path:
            messagebox.showerror("Error", "Please choose an output file.")
            return
        if not self.key_var.get().strip():
            messagebox.showerror("Error", "API key is required.")
            return

        try:
            max_rows = int(self.maxrows_var.get()) if self.maxrows_var.get().strip() else None
        except ValueError:
            messagebox.showerror("Error", "Max rows must be a whole number or blank.")
            return

        worker_config = {
            "api_key": self.key_var.get().strip(),
            "base_url": self.base_var.get().strip(),
            "model": self.model_var.get().strip(),
        }
        params = {
            "input": in_path, "output": out_path,
            "workers": self.workers_var.get(),
            "checkpoint": self.checkpoint_var.get(),
            "max_rows": max_rows,
            "engine": self.engine_var.get(),
            "worker_config": worker_config,
        }

        self.stop_event.clear()
        self.progress.config(value=0, maximum=100)
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.open_btn.config(state="disabled")
        self.status_var.set("Starting...")

        self.coordinator = Coordinator(params, self.msg_queue, self.stop_event)
        self.coordinator.start()

    def _stop(self):
        self.stop_event.set()
        self.status_var.set("Stopping (saving progress)...")
        self.stop_btn.config(state="disabled")

    def _open_folder(self):
        out = self.out_var.get().strip()
        folder = os.path.dirname(os.path.abspath(out))
        try:
            if sys.platform.startswith("win"):
                os.startfile(folder)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                os.system(f'open "{folder}"')
            else:
                os.system(f'xdg-open "{folder}"')
        except Exception:
            messagebox.showinfo("Output", f"Output saved in:\n{folder}")

    # ---- queue polling (keeps GUI responsive & thread-safe) ----
    def _poll_queue(self):
        try:
            while True:
                kind, payload = self.msg_queue.get_nowait()
                if kind == "log":
                    self._log(payload)
                elif kind == "total":
                    self.total = payload
                    self.progress.config(maximum=max(payload, 1), value=0)
                    self.status_var.set(f"Processing 0 / {payload}")
                elif kind == "progress":
                    self.progress.config(value=payload)
                    self.status_var.set(f"Processing {payload} / {self.total}")
                elif kind == "done":
                    self._on_done(payload)
        except queue.Empty:
            pass
        self.root.after(120, self._poll_queue)

    def _on_done(self, payload):
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.open_btn.config(state="normal")
        if payload.get("error"):
            self.status_var.set(f"Finished with error: {payload['error']}")
        else:
            self.status_var.set("Done.")
            messagebox.showinfo("Complete", f"Enrichment complete.\nSaved to:\n{payload.get('output','')}")


def main():
    root = tk.Tk()
    try:
        ttk.Style().theme_use("clam")
    except Exception:
        pass
    App(root)
    root.mainloop()


if __name__ == "__main__":
    multiprocessing.freeze_support()  # required for Windows 'spawn'
    main()
