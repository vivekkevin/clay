"""
enrichment_core.py
==================================================================
Address & Geo (Lat/Long) Enrichment - CORE ENGINE
==================================================================
This module is intentionally SIDE-EFFECT FREE and IMPORTABLE so that
it can be used safely by multiprocessing workers (Windows 'spawn' will
re-import this module in every child process; it must not run anything
at import time).

PIPELINE STRATEGY (best techniques merged from both source scripts):

  PRIORITY 1 - DIRECT SOURCE_URL SCRAPE
      If a SOURCE_URL is provided, scrape the page, hunt for map links /
      embedded coordinates, and ask the LLM to extract lat/long + address.
      Accept the result if we got coordinates OR a real street/city address.

  PRIORITY 2 - MULTI-QUERY WEB SEARCH FALLBACK
      1. Multi-query strategy (narrow -> broad)
      2. Cascading fallback with early-exit on high-quality hits
      3. Smart query variants (legal-suffix stripping, HQ, GPS)
      4. Trusted-source expansion (registries)
      5. Snippet scoring (rank best snippets first)
      6. City-level validation (PARTIAL instead of dropping)
      7. Anti-hallucination grounded system prompt
      8. Structured confidence scoring (HIGH/MED/LOW/NONE)
      9. Retry-with-broader-query on NOT_FOUND
     10. Regex coordinate rescue from maps URLs / raw text

  ROBUSTNESS
      - Every public entry point returns a dict and NEVER raises, so a
        single bad row can never kill a worker or the whole run.
      - LLM calls retry with exponential backoff on rate-limit / timeout.
      - JSON parsing is defensive (handles markdown fences / junk).
"""

import re
import json
import time
import urllib.parse

import requests
from bs4 import BeautifulSoup

# Search backend: the package is sometimes 'ddgs', sometimes 'duckduckgo_search'
try:
    from ddgs import DDGS  # newer package name
except Exception:  # pragma: no cover
    try:
        from duckduckgo_search import DDGS  # older package name
    except Exception:
        DDGS = None

from openai import OpenAI


# ──────────────────────────────────────────────────────────────────
# CONFIG  (overridable from the GUI; passed into every worker)
# ──────────────────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "api_key": "sk-Os-VNaj_3IreOr9xTfQKew",
    "base_url": "https://chatapi.straive.com",
    "model": "gemini/gemini-2.5-flash",
    "timeout": 30.0,
    "llm_retries": 4,
    "search_results_per_query": 5,
    "max_snippets": 6,
    "scrape_timeout": 15,
    "scrape_char_limit": 15000,
    "search_retries": 2,
}

# Per-worker globals (one OpenAI client per process/thread, created once).
_CLIENT = None
_CFG = dict(DEFAULT_CONFIG)


def init_worker(config: dict | None = None):
    """Initializer run once per worker (process or thread)."""
    global _CLIENT, _CFG
    _CFG = dict(DEFAULT_CONFIG)
    if config:
        _CFG.update({k: v for k, v in config.items() if v not in (None, "")})
    _CLIENT = OpenAI(
        api_key=_CFG["api_key"],
        base_url=_CFG["base_url"],
        timeout=float(_CFG["timeout"]),
    )


def _client() -> OpenAI:
    global _CLIENT
    if _CLIENT is None:
        init_worker(_CFG)
    return _CLIENT


# ──────────────────────────────────────────────────────────────────
# SMALL UTILITIES
# ──────────────────────────────────────────────────────────────────
def clean_str(v) -> str:
    """Turn anything (incl. NaN floats / None) into a clean trimmed string."""
    if v is None:
        return ""
    s = str(v).strip()
    if s.lower() in ("nan", "none", "null", "<na>"):
        return ""
    return s


def _result(match_type, address, confidence, lat, lon, justification, source_url):
    return {
        "match_type": match_type,
        "address": address,
        "confidence": confidence,
        "latitude": lat,
        "longitude": lon,
        "justification": justification,
        "source_url": source_url,
    }


def parse_coord(value, is_lat: bool):
    """
    Normalise a coordinate to a decimal string, or return None.
    Handles degree symbols, stray letters, and N/S/E/W direction suffixes.
    Validates plausible ranges.
    """
    if value is None:
        return None
    s = str(value).strip()
    if not s or s.lower() in ("nan", "none", "null"):
        return None

    sign = 1.0
    su = s.upper()
    if is_lat and "S" in su:
        sign = -1.0
    if (not is_lat) and "W" in su:
        sign = -1.0

    # Keep only digits, sign, decimal point.
    cleaned = re.sub(r"[^0-9\.\-]", "", s)
    if cleaned in ("", "-", ".", "-."):
        return None
    try:
        num = float(cleaned)
    except ValueError:
        return None
    if num < 0:  # an explicit minus already encodes direction
        sign = 1.0
    num = abs(num) * sign

    limit = 90.0 if is_lat else 180.0
    if not (-limit <= num <= limit):
        return None
    if num == 0.0:  # 0,0 is almost always a "null island" false positive
        return None
    return f"{num:.6f}".rstrip("0").rstrip(".")


def extract_coords(text: str):
    """
    Regex rescue: pull a (lat, lon) pair out of map URLs or raw text.
    Returns (lat_str, lon_str) or (None, None).
    """
    if not text:
        return None, None

    patterns = [
        r"@(-?\d{1,3}\.\d+),(-?\d{1,3}\.\d+)",          # google maps @lat,lng
        r"[?&]q=(-?\d{1,3}\.\d+),\s*(-?\d{1,3}\.\d+)",  # ?q=lat,lng
        r"[?&]ll=(-?\d{1,3}\.\d+),\s*(-?\d{1,3}\.\d+)", # ?ll=lat,lng
        r"!3d(-?\d{1,3}\.\d+)!4d(-?\d{1,3}\.\d+)",       # embedded place data
        r"lat(?:itude)?[\"'\s:=]+(-?\d{1,3}\.\d+).{0,40}?lon(?:gitude)?[\"'\s:=]+(-?\d{1,3}\.\d+)",
        r"(-?\d{1,2}\.\d{3,}),\s*(-?\d{1,3}\.\d{3,})",  # generic "lat, lng"
    ]
    for pat in patterns:
        m = re.search(pat, text, flags=re.IGNORECASE | re.DOTALL)
        if m:
            lat = parse_coord(m.group(1), is_lat=True)
            lon = parse_coord(m.group(2), is_lat=False)
            if lat and lon:
                return lat, lon
    return None, None


def is_real_address(addr: str) -> bool:
    if not addr:
        return False
    a = addr.strip().upper()
    return a not in ("", "NOT_FOUND", "N/A", "NA", "NONE", "UNKNOWN", "-", "NULL")


# ──────────────────────────────────────────────────────────────────
# PRIORITY 1 - DIRECT URL SCRAPE
# ──────────────────────────────────────────────────────────────────
def scrape_url_context(url: str) -> str:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
        )
    }
    try:
        resp = requests.get(url, headers=headers, timeout=_CFG["scrape_timeout"])
        resp.raise_for_status()
    except Exception as e:
        return f"Failed to scrape URL: {e}"

    try:
        soup = BeautifulSoup(resp.text, "html.parser")

        # Collect map / coordinate-bearing links before stripping the DOM.
        maps_links = []
        for a in soup.find_all("a", href=True):
            href = a["href"]
            low = href.lower()
            if any(k in low for k in ("maps", "lat=", "lng=", "ll=", "geo:", "@")):
                maps_links.append(href)

        # Also scan inline scripts/meta for coordinates before removing them.
        raw_for_coords = resp.text

        for tag in soup(["script", "style", "nav", "footer", "noscript", "svg"]):
            tag.decompose()
        text = soup.get_text(separator=" ", strip=True)
        text = text[: _CFG["scrape_char_limit"]]

        context = f"--- SCRAPED CONTENT FROM SOURCE_URL ---\n{text}\n"
        if maps_links:
            context += "\n--- MAP / GEO LINKS (LIKELY CONTAIN COORDINATES) ---\n"
            context += "\n".join(maps_links[:8])

        # Surface any regex-found coordinates for the model as a strong hint.
        lat, lon = extract_coords(raw_for_coords)
        if lat and lon:
            context += f"\n--- REGEX-DETECTED COORDINATES ---\nlatitude={lat}, longitude={lon}\n"
        return context
    except Exception as e:
        return f"Failed to parse scraped HTML: {e}"


# ──────────────────────────────────────────────────────────────────
# PRIORITY 2 - MULTI-QUERY WEB SEARCH
# ──────────────────────────────────────────────────────────────────
TRUSTED_SITES = (
    "(site:opencorporates.com OR site:dnb.com OR site:zaubacorp.com OR "
    "site:tofler.in OR site:indiafilings.com OR site:instafinancials.com)"
)

ADDRESS_KEYWORDS = [
    "address", "located at", "registered office", "headquartered", "office at",
    "pincode", "zip code", "postal code", "street", "road", "nagar", "sector",
    "district", "block", "floor", "building", "tower", "plot", "survey no",
    "village", "latitude", "longitude", "gps", "coordinates",
]


def build_queries(issuer, company, city, state, country) -> list:
    location = " ".join([p for p in (city, state, country) if p]).strip()
    search_target = f"{issuer} {company}".strip()
    clean_name = re.sub(
        r"\b(pvt|ltd|llc|inc|corp|limited|private|public|gmbh|llp|lp|plc|sa|ag|bv|nv|pty)\b",
        "", search_target, flags=re.IGNORECASE,
    ).strip()
    clean_name = re.sub(r"\s+", " ", clean_name)

    return [
        f"{search_target} {location} {TRUSTED_SITES} registered office address",
        f'"{clean_name}" {location} headquarters address',
        f"{search_target} {location} address location latitude longitude",
        f"{search_target} {location} project site location GPS coordinates",
    ]


def score_snippet(snippet: str) -> int:
    low = snippet.lower()
    return sum(1 for kw in ADDRESS_KEYWORDS if kw in low)


def _ddg_text(query: str, max_results: int):
    """Run one DDG search with light retry. Returns list of result dicts."""
    if DDGS is None:
        return []
    for attempt in range(int(_CFG["search_retries"]) + 1):
        try:
            with DDGS() as ddgs:
                return list(ddgs.text(query, max_results=max_results)) or []
        except Exception:
            time.sleep(1.0 + attempt)
    return []


def perform_web_search(queries: list, max_results_per_query: int = None):
    """
    Try queries in order, scoring snippets. Early-exit once a strong hit
    appears. Returns (formatted_context, best_source_url).
    """
    if max_results_per_query is None:
        max_results_per_query = int(_CFG["search_results_per_query"])

    all_snippets = []
    fallback_url = "https://www.google.com/search?q=" + urllib.parse.quote(queries[0])

    for q_idx, query in enumerate(queries):
        results = _ddg_text(query, max_results_per_query)
        for res in results:
            title = clean_str(res.get("title"))
            body = clean_str(res.get("body"))
            href = clean_str(res.get("href"))
            snippet = f"{title} - {body}".strip(" -")
            if snippet:
                all_snippets.append((score_snippet(snippet), snippet, href, q_idx + 1))

        if all_snippets and max(s[0] for s in all_snippets) >= 3:
            break  # good enough; stop escalating

    if not all_snippets:
        return "No web results found.", fallback_url

    all_snippets.sort(key=lambda x: x[0], reverse=True)
    lines = []
    for rank, (score, snippet, href, q_num) in enumerate(all_snippets[: int(_CFG["max_snippets"])], 1):
        lines.append(f"Result {rank} [Query#{q_num}, Score={score}]: {snippet}\n  Source: {href}")

    best_href = all_snippets[0][2] or fallback_url
    return "\n\n".join(lines), best_href


# ──────────────────────────────────────────────────────────────────
# LLM PROMPTING + CALL
# ──────────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """You are a corporate registry and physical asset verification engine.

YOUR ONLY JOB: Extract the real-world address, latitude, and longitude of the
company or asset from the CONTEXT provided.

STRICT GROUNDING RULES (read carefully):
- You may ONLY use text explicitly present in the provided context (scraped page
  text, map links, or web search results). NEVER invent data.
- PRIORITISE precise Latitude/Longitude found in text, map URLs (e.g. @12.34,56.78),
  or GPS strings. If a "REGEX-DETECTED COORDINATES" line is present, trust it.
- If a full street address is present, extract it exactly.
- CHOPPED TEXT: snippets often cut off mid-sentence. If the street-level address is
  cut off, stitch it together by appending the expected Target City, State, and
  Country so it forms a complete, usable address.
- If only CITY + STATE + COUNTRY is present (no street), output just that.
- NEVER invent street names, plot numbers, or coordinates not present in the context.
- Never use "approximately" or "near" style guesses.
- If TRULY nothing geographic is found, set match_type to NOT_FOUND.

CONFIDENCE LEVELS:
- HIGH: Full street/building address AND/OR exact Lat-Long found.
- MED : City + State + Country found (no street).
- LOW : Only country or state found.
- NONE: Nothing found.

OUTPUT FORMAT:
Return ONE valid JSON object with EXACTLY these keys (no markdown, no extra text):
{
  "match_type": "EXACT, PARTIAL, or NOT_FOUND",
  "address": "Full physical address, or NOT_FOUND",
  "confidence": "HIGH, MED, LOW, or NONE",
  "latitude": "Decimal degrees ONLY (e.g. 4.3930). Strip letters/symbols. Blank if none.",
  "longitude": "Decimal degrees ONLY (e.g. 113.9900). Strip letters/symbols. Blank if none.",
  "justification": "Brief explanation of how this was verified"
}
"""


def build_prompt(issuer, company, city, state, country, context, source_url, coords_hint=None):
    location = " ".join([p for p in (city, state, country) if p]).strip()
    hint = ""
    if coords_hint and coords_hint[0] and coords_hint[1]:
        hint = f"\nDETECTED COORDINATE HINT: latitude={coords_hint[0]}, longitude={coords_hint[1]}\n"
    return (
        f"Target Parent Issuer: '{issuer}'\n"
        f"Target Asset/Location Name: '{company}' (expected in: {location})\n"
        f"{hint}\n"
        f"--- CONTEXT START ---\n{context}\n--- CONTEXT END ---\n\n"
        "Now extract the best available Latitude, Longitude, and physical address "
        "following the rules above.\n"
        f"For SOURCE_URL, use: {source_url}"
    )


def _safe_json(raw: str) -> dict:
    """Defensive JSON parse: strips markdown fences and trailing junk."""
    if raw is None:
        return {}
    s = raw.strip()
    s = re.sub(r"^```(?:json)?", "", s).strip()
    s = re.sub(r"```$", "", s).strip()
    try:
        return json.loads(s)
    except Exception:
        # Last resort: grab the outermost {...} block.
        m = re.search(r"\{.*\}", s, flags=re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                pass
    return {}


def call_model(prompt: str) -> dict:
    retries = int(_CFG["llm_retries"])
    for attempt in range(retries):
        try:
            resp = _client().chat.completions.create(
                model=_CFG["model"],
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.0,
                response_format={"type": "json_object"},
            )
            data = _safe_json(resp.choices[0].message.content)
            if data:
                return data
            # Empty/garbled JSON -> try again.
        except Exception as e:
            err = str(e).lower()
            if "429" in err or "rate" in err:
                time.sleep(min(2 ** attempt, 30))
                continue
            if "timeout" in err:
                if attempt < retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                return _result("ERROR", "Server Timeout", "NONE", None, None,
                               "LLM proxy timed out.", "")
            # Unknown error: short backoff then retry, else fail cleanly.
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
                continue
            return _result("ERROR", "API Exception", "NONE", None, None,
                           f"Error: {e}", "")
    return _result("ERROR", "Max Retries Exceeded", "NONE", None, None,
                   "Failed to obtain valid LLM response.", "")


def normalize_result(raw: dict) -> dict:
    """Coerce an LLM dict into our canonical schema with validated coords."""
    raw = raw or {}
    match_type = clean_str(raw.get("match_type")).upper() or "UNKNOWN"
    if "EXACT" in match_type:
        match_type = "EXACT"
    elif "PARTIAL" in match_type:
        match_type = "PARTIAL"
    elif "NOT_FOUND" in match_type or "NOTFOUND" in match_type:
        match_type = "NOT_FOUND"
    elif match_type in ("ERROR", "SKIP"):
        pass
    else:
        match_type = "UNKNOWN"

    address = clean_str(raw.get("address")) or "NOT_FOUND"
    confidence = clean_str(raw.get("confidence")).upper()
    if confidence not in ("HIGH", "MED", "LOW", "NONE"):
        confidence = "NONE"

    lat = parse_coord(raw.get("latitude"), is_lat=True)
    lon = parse_coord(raw.get("longitude"), is_lat=False)

    justification = clean_str(raw.get("justification")) or "No justification provided."

    # City-level validation: if we have a usable address, never call it NOT_FOUND.
    if match_type == "NOT_FOUND" and is_real_address(address):
        match_type = "PARTIAL"
        if confidence == "NONE":
            confidence = "LOW"

    return _result(match_type, address, confidence, lat, lon, justification,
                   clean_str(raw.get("source_url")))


# ──────────────────────────────────────────────────────────────────
# PRIORITY 2 ORCHESTRATION (with NOT_FOUND broad retry)
# ──────────────────────────────────────────────────────────────────
def web_search_fallback(issuer, company, city, state, country) -> dict:
    queries = build_queries(issuer, company, city, state, country)
    context, src = perform_web_search(queries)
    coords_hint = extract_coords(context)

    prompt = build_prompt(issuer, company, city, state, country, context, src, coords_hint)
    result = normalize_result(call_model(prompt))
    result["source_url"] = src

    if result["match_type"] in ("NOT_FOUND", "UNKNOWN", "ERROR"):
        location = " ".join([p for p in (city, state, country) if p]).strip()
        broad_q = f"{issuer} {company} {location} address location contact coordinates".strip()
        b_context, b_src = perform_web_search([broad_q])
        b_hint = extract_coords(b_context)
        retry = normalize_result(
            call_model(build_prompt(issuer, company, city, state, country, b_context, b_src, b_hint))
        )
        retry["source_url"] = b_src
        if retry["match_type"] not in ("NOT_FOUND", "UNKNOWN", "ERROR"):
            retry["justification"] = "[SEARCH RETRY] " + retry["justification"]
            return retry

    return result


# ──────────────────────────────────────────────────────────────────
# PUBLIC WORKER ENTRY POINT  (picklable, never raises)
# ──────────────────────────────────────────────────────────────────
def enrich_record(record: dict) -> dict:
    """
    record keys: _idx, issuer, company, city, state, country, source_url
    Returns a dict with: _idx + match_type, address, confidence,
    latitude, longitude, justification, source_url
    """
    idx = record.get("_idx")
    try:
        issuer = clean_str(record.get("issuer"))
        company = clean_str(record.get("company"))
        city = clean_str(record.get("city"))
        state = clean_str(record.get("state"))
        country = clean_str(record.get("country"))
        source_url = clean_str(record.get("source_url"))

        if not company and not issuer:
            out = _result("SKIP", "Missing Data", "NONE", None, None,
                          "No input provided.", "")
            out["_idx"] = idx
            return out

        result = None

        # PRIORITY 1 — scrape the provided SOURCE_URL directly.
        if source_url.startswith("http"):
            try:
                ctx = scrape_url_context(source_url)
                coords_hint = extract_coords(ctx)
                r = normalize_result(
                    call_model(build_prompt(issuer, company, city, state, country,
                                            ctx, source_url, coords_hint))
                )
                has_coords = bool(r["latitude"] and r["longitude"])
                has_addr = is_real_address(r["address"])
                if r["match_type"] not in ("ERROR", "NOT_FOUND", "UNKNOWN") and (has_coords or has_addr):
                    r["source_url"] = source_url
                    r["justification"] = "[DIRECT SCRAPE] " + r["justification"]
                    result = r
            except Exception:
                result = None  # fall through to search

        # PRIORITY 2 — multi-query web search fallback.
        if result is None:
            result = web_search_fallback(issuer, company, city, state, country)

        if not result.get("source_url"):
            location = " ".join([p for p in (city, state, country) if p]).strip()
            q = urllib.parse.quote(f"{issuer} {company} {location} office address latitude longitude".strip())
            result["source_url"] = "https://www.google.com/search?q=" + q

        result["_idx"] = idx
        return result

    except Exception as e:
        out = _result("ERROR", "Worker Exception", "NONE", None, None,
                      f"Unhandled: {e}", "")
        out["_idx"] = idx
        return out
